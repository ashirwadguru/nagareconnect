# 🚀 Deployment Guide — Nagar eConnect

## Architecture
```
Netlify (Frontend)  ←→  Render (Backend)  ←→  MongoDB Atlas (Database)
     FREE                    FREE                    FREE (512MB)
```

---

## STEP 1 — MongoDB Atlas (Database)

1. Go to https://mongodb.com/atlas and create a free account
2. Create a free **M0 cluster** (choose Singapore region for India)
3. Click **Connect** → **Drivers** → copy the connection string
   - It looks like: `mongodb+srv://username:password@cluster0.xxxxx.mongodb.net/nagar_econnect`
4. Under **Network Access** → Add IP → click **"Allow Access from Anywhere"** (0.0.0.0/0)
5. Save your connection string — you'll need it in Step 2

---

## STEP 2 — Render (Backend)

1. Go to https://render.com and sign up (free)
2. Click **New** → **Web Service**
3. Connect your GitHub repo **OR** click "Deploy from existing code" and upload the `backend/` folder
4. Fill in:
   - **Name:** `nagar-econnect-backend`
   - **Root Directory:** `backend`
   - **Build Command:** `npm install`
   - **Start Command:** `node server.js`
   - **Instance Type:** Free
5. Under **Environment Variables**, add:
   ```
   MONGO_URI    = mongodb+srv://your-atlas-connection-string
   JWT_SECRET   = any-long-random-string-here-keep-secret
   NODE_ENV     = production
   PORT         = 10000
   ```
6. Click **Deploy** and wait ~2 minutes
7. Copy your backend URL — it looks like:
   `https://nagar-econnect-backend.onrender.com`

8. **Seed the database** — open this URL in your browser:
   `https://nagar-econnect-backend.onrender.com/api/admin/seed`
   (You should see: ✅ Database seeded with Odisha demo data!)

---

## STEP 3 — Update Frontend API URL

Open `frontend/.env.production` and replace with your actual Render URL:
```
REACT_APP_API_URL=https://nagar-econnect-backend.onrender.com/api
```

---

## STEP 4 — Netlify (Frontend)

### Option A: Drag & Drop (easiest, no GitHub needed)
1. Build the frontend locally:
   ```bash
   cd frontend
   npm install
   npm run build
   ```
2. Go to https://netlify.com → **Add new site** → **Deploy manually**
3. Drag the `frontend/build/` folder into the Netlify drop zone
4. Done! ✅

### Option B: GitHub (auto-deploys on every push)
1. Push your project to GitHub
2. Go to https://netlify.com → **Add new site** → **Import from Git**
3. Select your repo
4. Fill in build settings:
   - **Base directory:** `frontend`
   - **Build command:** `npm run build`
   - **Publish directory:** `frontend/build`
5. Under **Environment Variables** add:
   ```
   REACT_APP_API_URL = https://nagar-econnect-backend.onrender.com/api
   ```
6. Click **Deploy site**

---

## STEP 5 — Verify Everything Works

1. Open your Netlify URL (e.g. `https://amazing-site-123.netlify.app`)
2. You should see the Nagar eConnect login page
3. Login with demo credentials:
   - Admin: `admin@nagareconnect.in` / `Admin@123`
   - Citizen: `citizen@nagareconnect.in` / `Citizen@123`

---

## ❗ Common Errors & Fixes

| Error | Fix |
|-------|-----|
| Netlify 404 on page refresh | ✅ Already fixed — `_redirects` file included |
| Backend "Application Error" on Render | Check Environment Variables — MONGO_URI must be set |
| "Network Error" on frontend | Make sure REACT_APP_API_URL points to your Render URL |
| MongoDB connection refused | Add 0.0.0.0/0 in Atlas Network Access |
| Render backend sleeps after 15min | Free tier spins down — first request takes ~30s to wake up |

---

## ⚡ Render Free Tier Note

Render free tier **spins down after 15 minutes of inactivity**.
The first request after sleep takes ~30 seconds. This is normal on the free tier.

To avoid this, you can use a free service like **UptimeRobot** (https://uptimerobot.com)
to ping your backend URL every 10 minutes and keep it alive.
- Monitor URL: `https://nagar-econnect-backend.onrender.com/api/health`
- Interval: Every 10 minutes

---

## 📋 Summary

| Service | URL pattern | Cost |
|---------|-------------|------|
| MongoDB Atlas | cluster0.xxxxx.mongodb.net | Free (512MB) |
| Render Backend | nagar-econnect-backend.onrender.com | Free |
| Netlify Frontend | amazing-name-123.netlify.app | Free |
