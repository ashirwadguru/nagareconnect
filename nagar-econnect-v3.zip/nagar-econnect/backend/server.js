/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║   NAGAR eCONNECT — Backend Server v3.0                      ║
 * ║   Smart Civic Complaint Management — Odisha State           ║
 * ║   Fully automated: rewards, pay increments, status sync     ║
 * ╚══════════════════════════════════════════════════════════════╝
 */

require('dotenv').config();
const express = require('express');
const path = require('path');
const fs = require('fs');
const cors = require('cors');
const cron = require('node-cron');

const connectDB = require('./config/db');
const authRoutes = require('./routes/auth');
const complaintRoutes = require('./routes/complaints');
const assignmentRoutes = require('./routes/assignments');
const rewardRoutes = require('./routes/rewards');
const adminRoutes = require('./routes/admin');
const odishaRoutes = require('./routes/odisha');

const app = express();
const PORT = process.env.PORT || 5000;

connectDB();

// Middleware — allow Netlify frontend + localhost dev
const allowedOrigins = [
  'http://localhost:3000',
  'http://localhost:5000',
  /\.netlify\.app$/,
  /\.netlify\.com$/,
];
app.use(cors({
  origin: (origin, callback) => {
    // Allow requests with no origin (mobile, Postman, curl)
    if (!origin) return callback(null, true);
    const allowed = allowedOrigins.some(o =>
      typeof o === 'string' ? o === origin : o.test(origin)
    );
    callback(null, allowed || process.env.NODE_ENV !== 'production');
  },
  credentials: true,
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Serve frontend build if exists
const frontendBuild = path.join(__dirname, '..', 'frontend', 'build');
if (fs.existsSync(frontendBuild)) {
  app.use(express.static(frontendBuild));
}

// API Routes
app.use('/api/auth',        authRoutes);
app.use('/api/complaints',  complaintRoutes);
app.use('/api/assignments', assignmentRoutes);
app.use('/api/rewards',     rewardRoutes);
app.use('/api/admin',       adminRoutes);
app.use('/api/odisha',      odishaRoutes);

// Health Check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', version: '3.0.0', state: 'Odisha', timestamp: new Date() });
});

// Frontend fallback
app.get('*', (req, res) => {
  if (req.path.startsWith('/api')) {
    return res.status(404).json({ message: 'API route not found' });
  }
  if (fs.existsSync(path.join(frontendBuild, 'index.html'))) {
    res.sendFile(path.join(frontendBuild, 'index.html'));
  } else {
    res.json({ message: 'Nagar eConnect API v3.0 running. Build frontend first.' });
  }
});

// CRON: SLA breach checker - every hour
cron.schedule('0 * * * *', async () => {
  try {
    const Complaint = require('./models/Complaint');
    const result = await Complaint.updateMany(
      { slaDeadline: { $lt: new Date() }, status: { $nin: ['resolved', 'closed'] }, slaBreached: false },
      { slaBreached: true }
    );
    if (result.modifiedCount > 0) {
      console.log(`⚠️  SLA breach flagged for ${result.modifiedCount} complaints`);
    }
  } catch (err) {
    console.error('SLA cron error:', err.message);
  }
});

app.listen(PORT, () => {
  console.log(`\n🚀 Nagar eConnect API v3.0 running at http://localhost:${PORT}`);
  console.log(`📍 Odisha State Civic System`);
  console.log(`🌱 Seed: POST http://localhost:${PORT}/api/admin/seed\n`);
});

module.exports = app;
