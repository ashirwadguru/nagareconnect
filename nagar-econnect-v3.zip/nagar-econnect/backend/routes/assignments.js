const express = require('express');
const router = express.Router();
const Assignment = require('../models/Assignment');
const Complaint = require('../models/Complaint');
const User = require('../models/User');
const { authRequired, roleRequired } = require('../middleware/auth');
const { updateWorkerPay, awardCitizenPoints, REWARD_RULES } = require('../middleware/engine');

// ── POST /api/assignments — Create assignment ──────────────────────────────
router.post('/', authRequired, roleRequired('supervisor', 'admin'), async (req, res) => {
  try {
    const { complaintId, workerId, dueDate, notes } = req.body;

    const complaint = await Complaint.findById(complaintId);
    if (!complaint) return res.status(404).json({ message: 'Complaint not found' });

    const worker = await User.findOne({ _id: workerId, role: 'worker', isActive: true });
    if (!worker) return res.status(404).json({ message: 'Worker not found or inactive' });

    // Check if already assigned
    const existing = await Assignment.findOne({ complaint: complaintId, status: { $ne: 'completed' } });
    if (existing) return res.status(400).json({ message: 'Complaint already has an active assignment' });

    const assignment = await Assignment.create({
      complaint: complaintId,
      worker: workerId,
      supervisor: req.user.id,
      dueDate: dueDate || new Date(Date.now() + 48 * 3600000),
      notes,
      statusHistory: [{ status: 'assigned', changedBy: req.user.id, note: 'Assignment created', timestamp: new Date() }]
    });

    // AUTO: Update complaint status to 'assigned'
    await Complaint.findByIdAndUpdate(complaintId, {
      status: 'assigned',
      $push: { statusHistory: { status: 'assigned', changedBy: req.user.id, note: `Assigned to worker: ${worker.name}`, timestamp: new Date() } }
    });

    const populated = await Assignment.findById(assignment._id)
      .populate('complaint', 'title complaintId priority status')
      .populate('worker', 'name email phone')
      .populate('supervisor', 'name');

    res.status(201).json({ message: `Complaint assigned to ${worker.name}`, assignment: populated });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── GET /api/assignments — All assignments (supervisor/admin) ──────────────
router.get('/', authRequired, roleRequired('supervisor', 'admin'), async (req, res) => {
  try {
    const { status, workerId } = req.query;
    const filter = {};
    if (status) filter.status = status;
    if (workerId) filter.worker = workerId;

    const assignments = await Assignment.find(filter)
      .populate('complaint', 'title status priority location complaintId')
      .populate('worker', 'name email phone currentPay')
      .populate('supervisor', 'name')
      .sort('-createdAt');
    res.json({ assignments });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── GET /api/assignments/my — Worker's assignments ──────────────────────────
router.get('/my', authRequired, roleRequired('worker'), async (req, res) => {
  try {
    const assignments = await Assignment.find({ worker: req.user.id })
      .populate('complaint', 'title status priority location complaintId description images')
      .sort('-createdAt');
    res.json({ assignments });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── GET /api/assignments/workers/list — Workers with stats ─────────────────
router.get('/workers/list', authRequired, roleRequired('supervisor', 'admin'), async (req, res) => {
  try {
    const workers = await User.find({ role: 'worker', isActive: true }).select('name email phone district city currentPay performanceScore totalResolved');
    const workerStats = await Promise.all(workers.map(async w => {
      const [active, completed] = await Promise.all([
        Assignment.countDocuments({ worker: w._id, status: { $ne: 'completed' } }),
        Assignment.countDocuments({ worker: w._id, status: 'completed' })
      ]);
      return { ...w.toObject(), activeAssignments: active, completedAssignments: completed };
    }));
    res.json({ workers: workerStats });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── PUT /api/assignments/:id/status — AUTOMATED status update ──────────────
// When worker clicks "Update Status" → auto-syncs complaint + pay
router.put('/:id/status', authRequired, roleRequired('worker', 'supervisor', 'admin'), async (req, res) => {
  try {
    const { status, note } = req.body;
    const validStatuses = ['assigned', 'accepted', 'in_progress', 'completed'];
    if (!validStatuses.includes(status))
      return res.status(400).json({ message: `Invalid status. Valid: ${validStatuses.join(', ')}` });

    const assignment = await Assignment.findById(req.params.id).populate('complaint');
    if (!assignment) return res.status(404).json({ message: 'Assignment not found' });

    // Workers can only update their own assignments
    if (req.user.role === 'worker' && assignment.worker.toString() !== req.user.id) {
      return res.status(403).json({ message: 'You can only update your own assignments' });
    }

    const prevStatus = assignment.status;
    assignment.status = status;
    assignment.statusHistory.push({ status, changedBy: req.user.id, note, timestamp: new Date() });
    if (note) assignment.workerNotes = note;

    let autoActions = [];
    let complaintNewStatus = null;

    // AUTO SYNC: assignment status → complaint status
    if (status === 'accepted' && assignment.complaint.status === 'assigned') {
      complaintNewStatus = 'assigned'; // stays assigned until in_progress
    }
    if (status === 'in_progress') {
      complaintNewStatus = 'in_progress';
    }
    if (status === 'completed') {
      assignment.completedAt = new Date();
      complaintNewStatus = 'resolved';

      // AUTO: Update worker pay
      const payResult = await updateWorkerPay(assignment.worker);
      if (payResult) {
        autoActions.push(`Worker performance score updated to ${payResult.worker.performanceScore}`);
        if (payResult.nextMilestone) {
          autoActions.push(`${payResult.nextMilestone.remaining} more to next milestone (₹${payResult.nextMilestone.increment})`);
        }
      }

      // AUTO: Award citizen points when complaint resolved via worker
      const complaint = await Complaint.findById(assignment.complaint._id);
      if (complaint && !complaint.rewardGiven && complaint.citizen) {
        complaint.status = 'resolved';
        complaint.resolvedAt = new Date();
        complaint.resolvedBy = req.user.id;
        complaint.rewardGiven = true;
        const withinSLA = complaint.slaDeadline && new Date() <= complaint.slaDeadline;
        let bonusPoints = REWARD_RULES.genuine_verified;
        if (withinSLA) bonusPoints += REWARD_RULES.resolved_quickly;
        complaint.statusHistory.push({ status: 'resolved', changedBy: req.user.id, note: `Resolved by worker`, timestamp: new Date() });
        await complaint.save();
        await awardCitizenPoints(complaint.citizen, bonusPoints, `Complaint resolved by worker: ${complaint.complaintId}`, complaint.complaintId);
        autoActions.push(`Citizen awarded ${bonusPoints} reward points automatically`);
        complaintNewStatus = null; // already saved above
      }
    }

    // Sync complaint status if needed
    if (complaintNewStatus) {
      await Complaint.findByIdAndUpdate(assignment.complaint._id, {
        status: complaintNewStatus,
        $push: { statusHistory: { status: complaintNewStatus, changedBy: req.user.id, note: `Auto-synced from assignment: ${status}`, timestamp: new Date() } }
      });
      autoActions.push(`Complaint status auto-updated to "${complaintNewStatus}"`);
    }

    await assignment.save();

    const populated = await Assignment.findById(assignment._id)
      .populate('complaint', 'title complaintId status priority')
      .populate('worker', 'name email currentPay performanceScore');

    res.json({ message: `Assignment updated to "${status}"`, assignment: populated, autoActions });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
