const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Assignment = require('../models/Assignment');
const { authRequired, roleRequired } = require('../middleware/auth');
const { getNextTierInfo, PAY_INCREMENT_MILESTONES } = require('../middleware/engine');

// ── GET /api/rewards/my — Citizen's rewards ────────────────────────────────
router.get('/my', authRequired, roleRequired('citizen'), async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-password');
    if (!user) return res.status(404).json({ message: 'User not found' });

    const Complaint = require('../models/Complaint');
    const complaints = await Complaint.find({ citizen: req.user.id });
    const resolved = complaints.filter(c => c.status === 'resolved').length;
    const pending = complaints.filter(c => c.status === 'pending').length;

    res.json({
      points: user.rewardPoints || 0,
      tier: user.rewardTier || 'bronze',
      history: (user.rewardHistory || []).slice(-20).reverse(),
      totalComplaints: complaints.length,
      resolvedComplaints: resolved,
      pendingComplaints: pending,
      nextTier: getNextTierInfo(user.rewardPoints || 0)
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── GET /api/rewards/leaderboard ───────────────────────────────────────────
router.get('/leaderboard', async (req, res) => {
  try {
    const { district } = req.query;
    const filter = { role: 'citizen', rewardPoints: { $gt: 0 } };
    if (district) filter.district = district;

    const citizens = await User.find(filter)
      .select('name rewardPoints rewardTier district city')
      .sort('-rewardPoints')
      .limit(10);
    res.json({ leaderboard: citizens });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── GET /api/worker/pay — Worker's pay info ────────────────────────────────
router.get('/worker/pay', authRequired, roleRequired('worker'), async (req, res) => {
  try {
    const worker = await User.findById(req.user.id).select('-password');
    if (!worker) return res.status(404).json({ message: 'Not found' });

    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

    const [totalCompleted, monthlyCompleted] = await Promise.all([
      Assignment.countDocuments({ worker: req.user.id, status: 'completed' }),
      Assignment.countDocuments({ worker: req.user.id, status: 'completed', completedAt: { $gte: monthStart } })
    ]);

    const nextMilestone = PAY_INCREMENT_MILESTONES.find(m => totalCompleted < m.count);

    res.json({
      basePay: worker.basePay || 15000,
      currentPay: worker.currentPay || 15000,
      totalIncrements: (worker.currentPay || 15000) - (worker.basePay || 15000),
      payHistory: (worker.payIncrements || []).slice().reverse(),
      totalResolved: totalCompleted,
      monthlyResolved: monthlyCompleted,
      performanceScore: worker.performanceScore || 0,
      nextMilestone: nextMilestone
        ? { count: nextMilestone.count, increment: nextMilestone.increment, remaining: nextMilestone.count - totalCompleted }
        : null
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── GET /api/rewards/admin/overview — Admin: all citizens rewards ──────────
router.get('/admin/overview', authRequired, roleRequired('admin', 'supervisor'), async (req, res) => {
  try {
    const citizens = await User.find({ role: 'citizen' }).select('-password').sort('-rewardPoints');
    res.json({ citizens: citizens.map(c => ({
      _id: c._id, name: c.name, email: c.email, district: c.district, city: c.city,
      points: c.rewardPoints || 0, tier: c.rewardTier || 'bronze',
      history: c.rewardHistory || []
    }))});
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── GET /api/rewards/admin/workers — Admin: all workers pay summary ─────────
router.get('/admin/workers', authRequired, roleRequired('admin', 'supervisor'), async (req, res) => {
  try {
    const workers = await User.find({ role: 'worker' }).select('-password');
    const workerData = await Promise.all(workers.map(async w => {
      const now = new Date();
      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
      const [totalCompleted, monthlyCompleted] = await Promise.all([
        Assignment.countDocuments({ worker: w._id, status: 'completed' }),
        Assignment.countDocuments({ worker: w._id, status: 'completed', completedAt: { $gte: monthStart } })
      ]);
      return {
        _id: w._id, name: w.name, email: w.email, phone: w.phone,
        district: w.district, city: w.city,
        basePay: w.basePay || 15000, currentPay: w.currentPay || 15000,
        totalIncrements: (w.currentPay || 15000) - (w.basePay || 15000),
        totalResolved: totalCompleted, monthlyResolved: monthlyCompleted,
        performanceScore: w.performanceScore || 0, payHistory: w.payIncrements || []
      };
    }));
    res.json({ workers: workerData });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
