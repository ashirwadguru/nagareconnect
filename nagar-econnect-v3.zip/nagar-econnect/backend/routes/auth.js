const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { authRequired } = require('../middleware/auth');

const JWT_SECRET = process.env.JWT_SECRET || 'nagar_econnect_secret';
const signToken = (user) => jwt.sign(
  { id: user._id, role: user.role },
  JWT_SECRET,
  { expiresIn: '30d' }
);

const userPublicFields = (user) => ({
  _id: user._id,
  name: user.name,
  email: user.email,
  role: user.role,
  phone: user.phone,
  state: user.state,
  district: user.district,
  city: user.city,
  ward: user.ward,
  rewardPoints: user.rewardPoints || 0,
  rewardTier: user.rewardTier || 'bronze',
  totalResolved: user.totalResolved || 0,
  currentPay: user.currentPay || 15000,
  basePay: user.basePay || 15000,
  performanceScore: user.performanceScore || 0,
});

// POST /api/auth/register
router.post('/register', async (req, res) => {
  try {
    const { name, email, password, phone, district, city, ward } = req.body;

    if (!name || !email || !password)
      return res.status(400).json({ message: 'Name, email and password are required' });

    if (password.length < 6)
      return res.status(400).json({ message: 'Password must be at least 6 characters' });

    const existing = await User.findOne({ email: email.toLowerCase().trim() });
    if (existing)
      return res.status(400).json({ message: 'This email is already registered. Please log in.' });

    // Public registration = citizen only
    const user = await User.create({
      name: name.trim(),
      email: email.toLowerCase().trim(),
      password,
      phone: phone?.trim(),
      role: 'citizen',
      state: 'Odisha',
      district,
      city,
      ward
    });

    const token = signToken(user);
    res.status(201).json({
      message: 'Account created successfully! Welcome to Nagar eConnect.',
      token,
      user: userPublicFields(user)
    });
  } catch (err) {
    if (err.code === 11000)
      return res.status(400).json({ message: 'Email already registered.' });
    res.status(500).json({ message: 'Server error. Please try again.' });
  }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password)
      return res.status(400).json({ message: 'Email and password are required' });

    const user = await User.findOne({ email: email.toLowerCase().trim() });
    if (!user)
      return res.status(401).json({ message: 'Invalid email or password' });

    if (!user.isActive)
      return res.status(403).json({ message: 'Your account has been deactivated. Contact admin.' });

    const valid = await user.comparePassword(password);
    if (!valid)
      return res.status(401).json({ message: 'Invalid email or password' });

    const token = signToken(user);
    res.json({
      message: `Welcome back, ${user.name}!`,
      token,
      user: userPublicFields(user)
    });
  } catch (err) {
    res.status(500).json({ message: 'Server error. Please try again.' });
  }
});

// GET /api/auth/me
router.get('/me', authRequired, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-password');
    if (!user) return res.status(404).json({ message: 'User not found' });
    res.json({ user: userPublicFields(user) });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
