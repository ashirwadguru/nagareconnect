const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const Complaint = require('../models/Complaint');
const Assignment = require('../models/Assignment');
const { authRequired, roleRequired, optionalAuth } = require('../middleware/auth');
const {
  calculatePriority, getSLADeadline,
  awardCitizenPoints, updateWorkerPay,
  generateComplaintId, REWARD_RULES
} = require('../middleware/engine');

// Multer setup
if (!fs.existsSync('uploads')) fs.mkdirSync('uploads');
const storage = multer.diskStorage({
  destination: 'uploads/',
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `complaint_${Date.now()}_${Math.random().toString(36).slice(2)}${ext}`);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024, files: 3 },
  fileFilter: (req, file, cb) => {
    if (/image\/(jpeg|png|webp|gif)/.test(file.mimetype)) cb(null, true);
    else cb(new Error('Only image files allowed'));
  }
});

// ── POST /api/complaints — File a complaint ─────────────────────────────────
router.post('/', authRequired, roleRequired('citizen'), upload.array('images', 3), async (req, res) => {
  try {
    const { title, description, category, latitude, longitude, address, ward, city, district, pincode } = req.body;

    if (!title || !category)
      return res.status(400).json({ message: 'Title and category are required' });

    // Location is required — either from GPS or typed
    if (!latitude || !longitude)
      return res.status(400).json({ message: 'Location is required. Please enable GPS or type your address.' });

    const hasImages = (req.files?.length || 0) > 0;
    const { score, priority } = calculatePriority(category, description, hasImages);
    const complaintId = await generateComplaintId();
    const slaDeadline = getSLADeadline(priority);

    const images = (req.files || []).map(f => ({
      url: `/uploads/${f.filename}`,
      filename: f.filename
    }));

    const complaint = await Complaint.create({
      complaintId, title, description, category, priority, priorityScore: score,
      location: {
        type: 'Point',
        coordinates: [parseFloat(longitude), parseFloat(latitude)],
        address, ward, city, district: district || req.user.district,
        state: 'Odisha', pincode
      },
      images,
      citizen: req.user.id,
      slaDeadline,
      statusHistory: [{ status: 'pending', changedBy: req.user.id, note: 'Complaint filed', timestamp: new Date() }]
    });

    // Award points to citizen
    let pointsAwarded = REWARD_RULES.complaint_filed;
    const reasons = ['Complaint filed'];
    if (hasImages) { pointsAwarded += REWARD_RULES.has_photo; reasons.push('Photo added'); }
    if (priority === 'critical') { pointsAwarded += REWARD_RULES.critical_complaint; reasons.push('Critical issue'); }

    await awardCitizenPoints(req.user.id, pointsAwarded, reasons.join(', '), complaintId);
    await Complaint.findByIdAndUpdate(complaint._id, {}); // trigger re-index

    res.status(201).json({ message: 'Complaint submitted successfully!', complaint, pointsAwarded });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── GET /api/complaints — List (filtered, paginated) ───────────────────────
// Location-gated: requires district/city query params OR logged-in user's location
router.get('/', optionalAuth, async (req, res) => {
  try {
    const { status, priority, category, limit = 20, page = 1, sort = '-createdAt', district, city } = req.query;
    const filter = {};

    if (status) filter.status = status;
    if (priority) filter.priority = priority;
    if (category) filter.category = category;

    // Location gate: only show complaints for user's/requested location
    if (district) filter['location.district'] = district;
    else if (req.user?.district) filter['location.district'] = req.user.district;
    // If no location info at all, return empty (frontend must provide location)

    const [complaints, total] = await Promise.all([
      Complaint.find(filter)
        .sort(sort)
        .limit(parseInt(limit))
        .skip((parseInt(page) - 1) * parseInt(limit))
        .populate('citizen', 'name'),
      Complaint.countDocuments(filter)
    ]);

    res.json({ complaints, total, page: parseInt(page), pages: Math.ceil(total / parseInt(limit)) });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── GET /api/complaints/my — My complaints ─────────────────────────────────
router.get('/my', authRequired, async (req, res) => {
  try {
    const filter = { citizen: req.user.id };
    if (req.query.status) filter.status = req.query.status;
    const complaints = await Complaint.find(filter).sort('-createdAt');
    res.json({ complaints });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── GET /api/complaints/stats ──────────────────────────────────────────────
router.get('/stats', optionalAuth, async (req, res) => {
  try {
    const filter = {};
    const { district } = req.query;
    if (district) filter['location.district'] = district;
    else if (req.user?.district) filter['location.district'] = req.user.district;

    const [total, resolved, pending, inProgress, critical] = await Promise.all([
      Complaint.countDocuments(filter),
      Complaint.countDocuments({ ...filter, status: 'resolved' }),
      Complaint.countDocuments({ ...filter, status: 'pending' }),
      Complaint.countDocuments({ ...filter, status: 'in_progress' }),
      Complaint.countDocuments({ ...filter, priority: 'critical', status: { $ne: 'resolved' } }),
    ]);

    // SLA breaches
    const slaBreaches = await Complaint.countDocuments({
      ...filter,
      slaDeadline: { $lt: new Date() },
      status: { $nin: ['resolved', 'closed'] }
    });

    const resolutionRate = total > 0 ? Math.round((resolved / total) * 100) : 0;
    res.json({ total, resolved, pending, inProgress, critical, slaBreaches, resolutionRate });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── GET /api/complaints/map-data ───────────────────────────────────────────
router.get('/map-data', optionalAuth, async (req, res) => {
  try {
    const { status, priority, district } = req.query;
    const filter = {};
    if (status) filter.status = status;
    if (priority) filter.priority = priority;
    if (district) filter['location.district'] = district;
    else if (req.user?.district) filter['location.district'] = req.user.district;

    const complaints = await Complaint.find(filter)
      .select('title category priority status location upvotes complaintId createdAt')
      .limit(500);
    res.json({ complaints });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── GET /api/complaints/track/:complaintId ─────────────────────────────────
router.get('/track/:complaintId', async (req, res) => {
  try {
    const complaint = await Complaint.findOne({ complaintId: req.params.complaintId })
      .populate('citizen', 'name');
    if (!complaint) return res.status(404).json({ message: 'Complaint not found' });
    const assignment = await Assignment.findOne({ complaint: complaint._id })
      .populate('worker', 'name phone');
    res.json({ ...complaint.toObject(), workerAssigned: assignment?.worker || null, assignment });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── GET /api/complaints/:id ────────────────────────────────────────────────
router.get('/:id', async (req, res) => {
  try {
    const complaint = await Complaint.findById(req.params.id).populate('citizen', 'name');
    if (!complaint) return res.status(404).json({ message: 'Complaint not found' });
    const assignment = await Assignment.findOne({ complaint: complaint._id })
      .populate('worker', 'name phone');
    res.json({ ...complaint.toObject(), workerAssigned: assignment?.worker || null });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── PUT /api/complaints/:id/status ────────────────────────────────────────
// AUTOMATED: When status updated → auto-trigger reward points, worker pay, assignment sync
router.put('/:id/status', authRequired, roleRequired('worker', 'supervisor', 'admin'), async (req, res) => {
  try {
    const { status, note } = req.body;
    const validStatuses = ['pending', 'assigned', 'in_progress', 'resolved', 'closed'];
    if (!validStatuses.includes(status))
      return res.status(400).json({ message: `Invalid status. Valid: ${validStatuses.join(', ')}` });

    const complaint = await Complaint.findById(req.params.id);
    if (!complaint) return res.status(404).json({ message: 'Complaint not found' });

    const prevStatus = complaint.status;
    complaint.status = status;
    if (note) complaint.notes = note;
    complaint.statusHistory.push({ status, changedBy: req.user.id, note, timestamp: new Date() });

    let autoActions = [];

    if (status === 'resolved') {
      complaint.resolvedAt = new Date();
      complaint.resolvedBy = req.user.id;

      // AUTO: Award reward points to citizen
      if (!complaint.rewardGiven && complaint.citizen) {
        complaint.rewardGiven = true;
        const withinSLA = complaint.slaDeadline && new Date() <= complaint.slaDeadline;
        let bonusPoints = REWARD_RULES.genuine_verified;
        if (withinSLA) bonusPoints += REWARD_RULES.resolved_quickly;
        await awardCitizenPoints(
          complaint.citizen, bonusPoints,
          `Complaint resolved: ${complaint.complaintId}`, complaint.complaintId
        );
        autoActions.push(`Citizen awarded ${bonusPoints} reward points`);
      }

      // AUTO: Mark assignment as completed & update worker pay
      const assignment = await Assignment.findOne({ complaint: complaint._id, status: { $ne: 'completed' } });
      if (assignment) {
        assignment.status = 'completed';
        assignment.completedAt = new Date();
        assignment.statusHistory.push({ status: 'completed', changedBy: req.user.id, note: 'Auto-completed on complaint resolution', timestamp: new Date() });
        await assignment.save();
        const payResult = await updateWorkerPay(assignment.worker);
        if (payResult?.nextMilestone) {
          autoActions.push(`Worker pay updated. Next milestone: ${payResult.nextMilestone.count} complaints`);
        } else {
          autoActions.push('Worker performance score updated');
        }
      }
    }

    if (status === 'closed') {
      complaint.closedAt = new Date();
    }

    await complaint.save();

    const updatedComplaint = await Complaint.findById(complaint._id).populate('citizen', 'name');
    res.json({
      message: `Status updated to "${status}"`,
      complaint: updatedComplaint,
      autoActions
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── POST /api/complaints/:id/upvote ───────────────────────────────────────
router.post('/:id/upvote', authRequired, async (req, res) => {
  try {
    const complaint = await Complaint.findById(req.params.id);
    if (!complaint) return res.status(404).json({ message: 'Not found' });
    const userId = req.user.id;
    const alreadyVoted = complaint.upvotedBy.some(id => id.toString() === userId);
    if (alreadyVoted) {
      complaint.upvotes = Math.max(0, complaint.upvotes - 1);
      complaint.upvotedBy.pull(userId);
    } else {
      complaint.upvotes += 1;
      complaint.upvotedBy.push(userId);
    }
    await complaint.save();
    res.json({ upvotes: complaint.upvotes, voted: !alreadyVoted });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── POST /api/complaints/:id/feedback ─────────────────────────────────────
router.post('/:id/feedback', authRequired, roleRequired('citizen'), async (req, res) => {
  try {
    const { rating, comment } = req.body;
    if (!rating || rating < 1 || rating > 5)
      return res.status(400).json({ message: 'Rating between 1-5 is required' });

    const complaint = await Complaint.findOneAndUpdate(
      { _id: req.params.id, citizen: req.user.id, status: 'resolved' },
      { feedback: { rating, comment, submittedAt: new Date() } },
      { new: true }
    );
    if (!complaint)
      return res.status(404).json({ message: 'Complaint not found or not eligible for feedback' });

    await awardCitizenPoints(req.user.id, REWARD_RULES.feedback_submitted, 'Feedback submitted', complaint.complaintId);
    res.json({ message: 'Feedback submitted! You earned 5 reward points.', complaint });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
