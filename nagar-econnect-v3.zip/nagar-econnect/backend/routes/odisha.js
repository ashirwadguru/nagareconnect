const express = require('express');
const router = express.Router();
const ODISHA_DATA = require('../config/odisha');

// GET /api/odisha — Full state data
router.get('/', (req, res) => {
  res.json(ODISHA_DATA);
});

// GET /api/odisha/districts — Districts list
router.get('/districts', (req, res) => {
  res.json({ districts: ODISHA_DATA.districts.map(d => d.name) });
});

// GET /api/odisha/cities/:district — Cities for a district
router.get('/cities/:district', (req, res) => {
  const district = ODISHA_DATA.districts.find(d => d.name === req.params.district);
  if (!district) return res.status(404).json({ message: 'District not found' });
  res.json({ cities: district.cities });
});

// GET /api/odisha/wards/:district — Wards for a district
router.get('/wards/:district', (req, res) => {
  const district = ODISHA_DATA.districts.find(d => d.name === req.params.district);
  if (!district) return res.status(404).json({ message: 'District not found' });
  res.json({ wards: district.wards });
});

module.exports = router;
