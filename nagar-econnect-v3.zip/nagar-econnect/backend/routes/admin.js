const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Complaint = require('../models/Complaint');
const Assignment = require('../models/Assignment');
const { authRequired, roleRequired } = require('../middleware/auth');
const { calculatePriority, getSLADeadline, generateComplaintId } = require('../middleware/engine');

// ── POST /api/admin/seed ───────────────────────────────────────────────────
router.post('/seed', async (req, res) => {
  try {
    const users = [
      { name: 'Admin Odisha',        email: 'admin@nagareconnect.in',      password: 'Admin@123',   role: 'admin',      district: 'Bhubaneswar', city: 'Bhubaneswar City' },
      { name: 'Supervisor Patnaik',  email: 'supervisor@nagareconnect.in', password: 'Super@123',   role: 'supervisor', district: 'Bhubaneswar', city: 'Bhubaneswar City' },
      { name: 'Worker Biswal',       email: 'worker@nagareconnect.in',     password: 'Worker@123',  role: 'worker',     district: 'Bhubaneswar', city: 'Bhubaneswar City', basePay: 15000, currentPay: 15000 },
      { name: 'Worker Pradhan',      email: 'worker2@nagareconnect.in',    password: 'Worker@123',  role: 'worker',     district: 'Cuttack',     city: 'Cuttack City',     basePay: 15000, currentPay: 17500 },
      { name: 'Worker Nayak',        email: 'worker3@nagareconnect.in',    password: 'Worker@123',  role: 'worker',     district: 'Rourkela',    city: 'Rourkela City',    basePay: 15000, currentPay: 16000 },
      { name: 'Ramesh Mohapatra',    email: 'citizen@nagareconnect.in',    password: 'Citizen@123', role: 'citizen',    district: 'Bhubaneswar', city: 'Bhubaneswar City', rewardPoints: 85,  rewardTier: 'bronze' },
      { name: 'Sunita Das',          email: 'citizen2@nagareconnect.in',   password: 'Citizen@123', role: 'citizen',    district: 'Cuttack',     city: 'Cuttack City',     rewardPoints: 320, rewardTier: 'gold' },
      { name: 'Priya Sahu',          email: 'citizen3@nagareconnect.in',   password: 'Citizen@123', role: 'citizen',    district: 'Rourkela',    city: 'Rourkela City',    rewardPoints: 650, rewardTier: 'platinum' },
      { name: 'Arjun Jena',          email: 'citizen4@nagareconnect.in',   password: 'Citizen@123', role: 'citizen',    district: 'Puri',        city: 'Puri City',        rewardPoints: 140, rewardTier: 'silver' },
    ];

    for (const u of users) {
      const existing = await User.findOne({ email: u.email });
      if (!existing) await User.create(u);
    }

    const citizen = await User.findOne({ email: 'citizen@nagareconnect.in' });
    const citizen2 = await User.findOne({ email: 'citizen2@nagareconnect.in' });

    const demoComplaints = [
      // Bhubaneswar
      { title: 'Overflowing Bin near Rajmahal Square', category: 'overflowing_bin', description: 'Bin overflowing urgently, causing smell', lat: 20.2961, lng: 85.8245, address: 'Rajmahal Square, Bhubaneswar', district: 'Bhubaneswar', city: 'Bhubaneswar City', ward: 'Ward 5', status: 'pending', citizenEmail: 'citizen@nagareconnect.in' },
      { title: 'Sewage Overflow near Kalpana Square', category: 'sewage_overflow', description: 'Sewage blocking road, flooding footpath', lat: 20.2700, lng: 85.8440, address: 'Kalpana Square, Bhubaneswar', district: 'Bhubaneswar', city: 'Bhubaneswar City', ward: 'Ward 12', status: 'in_progress', citizenEmail: 'citizen@nagareconnect.in' },
      { title: 'Pothole on Nayapalli Road', category: 'pothole', description: 'Large pothole causing accidents', lat: 20.2900, lng: 85.8100, address: 'Nayapalli, Bhubaneswar', district: 'Bhubaneswar', city: 'Bhubaneswar City', ward: 'Ward 3', status: 'resolved', citizenEmail: 'citizen@nagareconnect.in' },
      { title: 'Waterlogging at Unit 4 Market', category: 'waterlogging', description: 'Waterlogging after rain, dangerous for pedestrians', lat: 20.2601, lng: 85.8392, address: 'Unit 4 Market, Bhubaneswar', district: 'Bhubaneswar', city: 'Bhubaneswar City', ward: 'Ward 8', status: 'pending', citizenEmail: 'citizen@nagareconnect.in' },
      // Cuttack
      { title: 'Dead Animal near Badambadi', category: 'dead_animal', description: 'Dead dog lying on roadside causing smell hazard', lat: 20.4625, lng: 85.8830, address: 'Badambadi, Cuttack', district: 'Cuttack', city: 'Cuttack City', ward: 'Ward 2', status: 'pending', citizenEmail: 'citizen2@nagareconnect.in' },
      { title: 'Illegal Garbage Dumping at Buxi Bazaar', category: 'garbage_dumping', description: 'Regular illegal dumping by shopkeepers', lat: 20.4700, lng: 85.8800, address: 'Buxi Bazaar, Cuttack', district: 'Cuttack', city: 'Cuttack City', ward: 'Ward 7', status: 'in_progress', citizenEmail: 'citizen2@nagareconnect.in' },
      // Rourkela
      { title: 'Broken Streetlight near Steel Gate', category: 'streetlight_issue', description: 'Street dark for a week, unsafe at night', lat: 22.2604, lng: 85.8312, address: 'Steel Gate, Rourkela', district: 'Rourkela', city: 'Rourkela City', ward: 'Ward 15', status: 'pending', citizenEmail: 'citizen3@nagareconnect.in' },
      { title: 'Construction Debris on Chhend Road', category: 'construction_debris', description: 'Builder left debris blocking half the road', lat: 22.2600, lng: 85.8100, address: 'Chhend Colony, Rourkela', district: 'Rourkela', city: 'Rourkela City', ward: 'Ward 22', status: 'resolved', citizenEmail: 'citizen3@nagareconnect.in' },
      // Puri
      { title: 'Stray Dogs near Puri Beach Road', category: 'stray_animals', description: 'Pack of stray dogs near tourist area, danger to visitors', lat: 19.7980, lng: 85.8270, address: 'Marine Drive, Puri', district: 'Puri', city: 'Puri City', ward: 'Ward 4', status: 'pending', citizenEmail: 'citizen4@nagareconnect.in' },
    ];

    for (const d of demoComplaints) {
      const existing = await Complaint.findOne({ title: d.title });
      if (!existing) {
        const { score, priority } = calculatePriority(d.category, d.description);
        const complaintId = await generateComplaintId();
        const slaDeadline = getSLADeadline(priority);
        const citizenUser = await User.findOne({ email: d.citizenEmail });
        await Complaint.create({
          complaintId, title: d.title, description: d.description,
          category: d.category, priority, priorityScore: score,
          location: {
            type: 'Point', coordinates: [d.lng, d.lat],
            address: d.address, ward: d.ward, city: d.city,
            district: d.district, state: 'Odisha'
          },
          citizen: citizenUser?._id,
          status: d.status, slaDeadline,
          upvotes: Math.floor(Math.random() * 15),
          resolvedAt: d.status === 'resolved' ? new Date() : undefined,
          rewardGiven: d.status === 'resolved',
          statusHistory: [{ status: 'pending', note: 'Complaint filed (seed)', timestamp: new Date() }]
        });
      }
    }

    res.json({ message: '✅ Database seeded with Odisha demo data! 9 users, 9 complaints created.' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── GET /api/admin/dashboard — Admin dashboard stats ──────────────────────
router.get('/dashboard', authRequired, roleRequired('admin', 'supervisor'), async (req, res) => {
  try {
    const [
      totalUsers, totalCitizens, totalWorkers,
      totalComplaints, pendingComplaints, resolvedComplaints, inProgressComplaints,
      criticalComplaints, slaBreaches,
      recentComplaints
    ] = await Promise.all([
      User.countDocuments(),
      User.countDocuments({ role: 'citizen' }),
      User.countDocuments({ role: 'worker' }),
      Complaint.countDocuments(),
      Complaint.countDocuments({ status: 'pending' }),
      Complaint.countDocuments({ status: 'resolved' }),
      Complaint.countDocuments({ status: 'in_progress' }),
      Complaint.countDocuments({ priority: 'critical', status: { $nin: ['resolved', 'closed'] } }),
      Complaint.countDocuments({ slaDeadline: { $lt: new Date() }, status: { $nin: ['resolved', 'closed'] } }),
      Complaint.find().sort('-createdAt').limit(10).populate('citizen', 'name')
    ]);

    // District-wise breakdown
    const districtBreakdown = await Complaint.aggregate([
      { $group: { _id: '$location.district', count: { $sum: 1 }, resolved: { $sum: { $cond: [{ $eq: ['$status', 'resolved'] }, 1, 0] } } } },
      { $sort: { count: -1 } }
    ]);

    res.json({
      users: { total: totalUsers, citizens: totalCitizens, workers: totalWorkers },
      complaints: {
        total: totalComplaints, pending: pendingComplaints,
        resolved: resolvedComplaints, inProgress: inProgressComplaints,
        critical: criticalComplaints, slaBreaches,
        resolutionRate: totalComplaints > 0 ? Math.round((resolvedComplaints / totalComplaints) * 100) : 0
      },
      recentComplaints,
      districtBreakdown
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── GET /api/admin/users ───────────────────────────────────────────────────
router.get('/users', authRequired, roleRequired('admin'), async (req, res) => {
  try {
    const { role } = req.query;
    const filter = role ? { role } : {};
    const users = await User.find(filter).select('-password').sort('-createdAt');
    res.json({ users });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── POST /api/admin/users — Create worker/supervisor ──────────────────────
router.post('/users', authRequired, roleRequired('admin'), async (req, res) => {
  try {
    const { name, email, password, phone, role, district, city, ward } = req.body;
    if (!['worker', 'supervisor', 'admin'].includes(role))
      return res.status(400).json({ message: 'Can only create worker/supervisor/admin' });

    const existing = await User.findOne({ email: email?.toLowerCase().trim() });
    if (existing) return res.status(400).json({ message: 'Email already registered' });

    const user = await User.create({ name, email, password, phone, role, district, city, ward, state: 'Odisha' });
    res.status(201).json({ message: `${role} account created successfully`, user: { _id: user._id, name: user.name, email: user.email, role: user.role } });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── PUT /api/admin/users/:id/toggle-active ────────────────────────────────
router.put('/users/:id/toggle-active', authRequired, roleRequired('admin'), async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ message: 'User not found' });
    user.isActive = !user.isActive;
    await user.save();
    res.json({ message: `User ${user.isActive ? 'activated' : 'deactivated'}`, isActive: user.isActive });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
