// Odisha State — Districts, Cities and Wards
const ODISHA_DATA = {
  state: "Odisha",
  districts: [
    {
      name: "Bhubaneswar",
      cities: ["Bhubaneswar City", "Khurda", "Jatni", "Bhubaneswar North"],
      wards: Array.from({ length: 67 }, (_, i) => `Ward ${i + 1}`)
    },
    {
      name: "Cuttack",
      cities: ["Cuttack City", "Choudwar", "Athagarh", "Banki"],
      wards: Array.from({ length: 59 }, (_, i) => `Ward ${i + 1}`)
    },
    {
      name: "Rourkela",
      cities: ["Rourkela City", "Bonai", "Rajgangpur", "Sundargarh"],
      wards: Array.from({ length: 48 }, (_, i) => `Ward ${i + 1}`)
    },
    {
      name: "Puri",
      cities: ["Puri City", "Konark", "Nimapara", "Brahmagiri"],
      wards: Array.from({ length: 35 }, (_, i) => `Ward ${i + 1}`)
    },
    {
      name: "Sambalpur",
      cities: ["Sambalpur City", "Burla", "Hirakud", "Jharsuguda"],
      wards: Array.from({ length: 40 }, (_, i) => `Ward ${i + 1}`)
    },
    {
      name: "Berhampur",
      cities: ["Berhampur City", "Gopalpur", "Chhatrapur", "Aska"],
      wards: Array.from({ length: 40 }, (_, i) => `Ward ${i + 1}`)
    },
    {
      name: "Balasore",
      cities: ["Balasore City", "Bhadrak", "Jaleswar", "Soro"],
      wards: Array.from({ length: 35 }, (_, i) => `Ward ${i + 1}`)
    },
    {
      name: "Angul",
      cities: ["Angul City", "Talcher", "Athamalik", "Pallahara"],
      wards: Array.from({ length: 30 }, (_, i) => `Ward ${i + 1}`)
    },
    {
      name: "Koraput",
      cities: ["Koraput City", "Jeypore", "Sunabeda", "Nabarangpur"],
      wards: Array.from({ length: 25 }, (_, i) => `Ward ${i + 1}`)
    },
    {
      name: "Kendrapara",
      cities: ["Kendrapara City", "Pattamundai", "Marshaghai", "Rajnagar"],
      wards: Array.from({ length: 22 }, (_, i) => `Ward ${i + 1}`)
    }
  ]
};

module.exports = ODISHA_DATA;
