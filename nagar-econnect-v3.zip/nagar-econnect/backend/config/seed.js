/**
 * Run with: node config/seed.js
 * Seeds the database with Odisha demo users and complaints.
 */
require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });
const mongoose = require('mongoose');

async function seed() {
  await mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/nagar_econnect');
  console.log('✅ Connected to MongoDB');

  // Trigger the seed endpoint logic via direct model ops
  const res = await fetch(`http://localhost:${process.env.PORT || 5000}/api/admin/seed`, { method: 'POST' });
  const data = await res.json();
  console.log(data.message);
  process.exit(0);
}

seed().catch(err => { console.error(err); process.exit(1); });
