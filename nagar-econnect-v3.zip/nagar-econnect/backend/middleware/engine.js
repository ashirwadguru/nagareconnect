const User = require('../models/User');
const Assignment = require('../models/Assignment');

// ── Priority Engine ─────────────────────────────────────────────────────────
const BASE_SCORES = {
  dead_animal: 90, sewage_overflow: 88, waterlogging: 82, road_blockage: 78,
  pothole: 72, overflowing_bin: 70, illegal_encroachment: 68,
  stray_animals: 65, garbage_dumping: 62, streetlight_issue: 58,
  construction_debris: 52, other: 40
};

const URGENT_WORDS = ['urgent','emergency','smell','blocking','hazard','dead',
  'dangerous','overflow','flood','fire','injury','accident','bleeding','child'];

function calculatePriority(category, description = '', hasImages = false) {
  let score = BASE_SCORES[category] || 40;
  if (hasImages) score += 5;
  URGENT_WORDS.forEach(w => {
    if (description.toLowerCase().includes(w)) score += 3;
  });
  score = Math.min(score, 100);
  let priority;
  if (score >= 85) priority = 'critical';
  else if (score >= 70) priority = 'high';
  else if (score >= 50) priority = 'medium';
  else priority = 'low';
  return { score, priority };
}

// SLA deadlines based on priority (in hours)
const SLA_HOURS = { critical: 24, high: 48, medium: 96, low: 168 };

function getSLADeadline(priority) {
  const hours = SLA_HOURS[priority] || 96;
  return new Date(Date.now() + hours * 3600000);
}

// ── Reward Points Engine ────────────────────────────────────────────────────
const REWARD_RULES = {
  complaint_filed:    10,
  has_photo:           5,
  genuine_verified:   20,
  resolved_quickly:   15,
  feedback_submitted:  5,
  critical_complaint: 25,
};

const TIER_THRESHOLDS = { bronze: 0, silver: 100, gold: 300, platinum: 600 };

function getNextTierInfo(points) {
  if (points < 100) return { tier: 'silver', needed: 100 - points, current: 'bronze' };
  if (points < 300) return { tier: 'gold',   needed: 300 - points, current: 'silver' };
  if (points < 600) return { tier: 'platinum', needed: 600 - points, current: 'gold' };
  return { tier: 'platinum', needed: 0, current: 'platinum' };
}

async function awardCitizenPoints(userId, points, reason, complaintId) {
  try {
    const user = await User.findById(userId);
    if (!user || user.role !== 'citizen') return null;
    user.rewardPoints += points;
    user.rewardHistory.push({ points, reason, complaintId });
    user.rewardTier = User.getRewardTier(user.rewardPoints);
    await user.save();
    return user.rewardPoints;
  } catch (err) {
    console.error('Reward award error:', err.message);
    return null;
  }
}

// ── Worker Pay Engine ───────────────────────────────────────────────────────
const PAY_INCREMENT_MILESTONES = [
  { count: 5,   increment: 500,  reason: '5 complaints resolved — ₹500 increment' },
  { count: 10,  increment: 750,  reason: '10 complaints resolved — ₹750 increment' },
  { count: 20,  increment: 1000, reason: '20 complaints milestone — ₹1,000 increment' },
  { count: 30,  increment: 1500, reason: '30 complaints — ₹1,500 increment' },
  { count: 50,  increment: 2000, reason: '50 complaints — ₹2,000 increment' },
  { count: 75,  increment: 2500, reason: '75 complaints — ₹2,500 increment' },
  { count: 100, increment: 3000, reason: '100 complaints milestone — ₹3,000 increment' },
];

async function updateWorkerPay(workerId) {
  try {
    const worker = await User.findById(workerId);
    if (!worker || worker.role !== 'worker') return;

    const resolvedCount = await Assignment.countDocuments({ worker: workerId, status: 'completed' });
    worker.totalResolved = resolvedCount;
    worker.performanceScore = Math.min(100, Math.round(resolvedCount * 1.5));

    for (const milestone of PAY_INCREMENT_MILESTONES) {
      const alreadyAwarded = worker.payIncrements.some(p => p.milestone === milestone.count);
      if (resolvedCount >= milestone.count && !alreadyAwarded) {
        worker.currentPay += milestone.increment;
        worker.payIncrements.push({
          amount: milestone.increment,
          reason: milestone.reason,
          milestone: milestone.count,
          date: new Date()
        });
        console.log(`💰 Worker ${worker.name} received pay increment: ₹${milestone.increment} (milestone: ${milestone.count})`);
      }
    }

    const nextMilestone = PAY_INCREMENT_MILESTONES.find(m => resolvedCount < m.count);
    worker.lastPayReview = new Date();
    await worker.save();
    return { worker, nextMilestone };
  } catch (err) {
    console.error('Worker pay update error:', err.message);
  }
}

// ── Complaint ID Generator ──────────────────────────────────────────────────
const Complaint = require('../models/Complaint');

async function generateComplaintId() {
  const now = new Date();
  const dd = String(now.getDate()).padStart(2, '0');
  const mm = String(now.getMonth() + 1).padStart(2, '0');
  const yy = String(now.getFullYear()).slice(2);
  const count = await Complaint.countDocuments();
  return `NEC-${yy}${mm}${dd}-${String(count + 1).padStart(5, '0')}`;
}

module.exports = {
  calculatePriority,
  getSLADeadline,
  awardCitizenPoints,
  updateWorkerPay,
  generateComplaintId,
  REWARD_RULES,
  PAY_INCREMENT_MILESTONES,
  getNextTierInfo
};
