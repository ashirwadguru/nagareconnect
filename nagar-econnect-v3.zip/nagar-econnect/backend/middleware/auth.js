const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Verify JWT token
const authRequired = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'No token provided. Please log in.' });
  }
  const token = authHeader.split(' ')[1];
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET || 'nagar_econnect_secret');
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Invalid or expired token. Please log in again.' });
  }
};

// Role-based access control
const roleRequired = (...roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ message: `Access denied. Required role(s): ${roles.join(', ')}` });
    }
    next();
  };
};

// Optional auth (attach user if token present, but don't fail)
const optionalAuth = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    try {
      req.user = jwt.verify(authHeader.split(' ')[1], process.env.JWT_SECRET || 'nagar_econnect_secret');
    } catch (_) {}
  }
  next();
};

module.exports = { authRequired, roleRequired, optionalAuth };
