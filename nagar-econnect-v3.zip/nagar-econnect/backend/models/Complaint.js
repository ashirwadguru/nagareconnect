const mongoose = require('mongoose');

const ComplaintSchema = new mongoose.Schema({
  complaintId:   { type: String, unique: true },
  title:         { type: String, required: true, maxlength: 200, trim: true },
  description:   { type: String, maxlength: 1000, trim: true },
  category: {
    type: String,
    enum: ['dead_animal','sewage_overflow','road_blockage','overflowing_bin',
           'stray_animals','garbage_dumping','construction_debris','waterlogging',
           'streetlight_issue','pothole','illegal_encroachment','other'],
    required: true
  },
  priority:      { type: String, enum: ['critical','high','medium','low'], default: 'medium' },
  priorityScore: { type: Number, default: 40 },
  status: {
    type: String,
    enum: ['pending','assigned','in_progress','resolved','closed'],
    default: 'pending'
  },

  // Location — Odisha specific
  location: {
    type:        { type: String, default: 'Point' },
    coordinates: { type: [Number], default: [0, 0] }, // [lng, lat]
    address:     String,
    ward:        String,
    city:        String,
    district:    String,
    state:       { type: String, default: 'Odisha' },
    pincode:     String,
  },

  images:      [{ url: String, filename: String }],
  citizen:     { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  upvotes:     { type: Number, default: 0 },
  upvotedBy:   [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],

  resolvedAt:  Date,
  resolvedBy:  { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  closedAt:    Date,
  notes:       String,

  isGenuine:   { type: Boolean, default: true },
  rewardGiven: { type: Boolean, default: false },

  feedback: {
    rating:      { type: Number, min: 1, max: 5 },
    comment:     String,
    submittedAt: Date,
  },

  // SLA tracking
  slaDeadline: Date,
  slaBreached: { type: Boolean, default: false },

  // Status history for audit trail
  statusHistory: [{
    status:    String,
    changedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    note:      String,
    timestamp: { type: Date, default: Date.now }
  }]
}, { timestamps: true });

ComplaintSchema.index({ location: '2dsphere' });
ComplaintSchema.index({ status: 1, priority: 1 });
ComplaintSchema.index({ 'location.district': 1, 'location.city': 1 });
ComplaintSchema.index({ citizen: 1 });

module.exports = mongoose.model('Complaint', ComplaintSchema);
