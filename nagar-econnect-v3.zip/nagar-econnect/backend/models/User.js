const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const RewardHistorySchema = new mongoose.Schema({
  points:      { type: Number, required: true },
  reason:      { type: String, required: true },
  complaintId: String,
  date:        { type: Date, default: Date.now }
}, { _id: false });

const PayIncrementSchema = new mongoose.Schema({
  amount:    { type: Number, required: true },
  reason:    { type: String, required: true },
  milestone: { type: Number, required: true },
  date:      { type: Date, default: Date.now }
}, { _id: false });

const UserSchema = new mongoose.Schema({
  name:     { type: String, required: true, trim: true },
  email:    { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String, required: true, minlength: 6 },
  phone:    { type: String, trim: true },
  role:     { type: String, enum: ['citizen', 'worker', 'supervisor', 'admin'], default: 'citizen' },

  // Location info (Odisha)
  state:    { type: String, default: 'Odisha' },
  district: { type: String },
  city:     { type: String },
  ward:     { type: String },

  isActive: { type: Boolean, default: true },

  // Citizen reward points
  rewardPoints:           { type: Number, default: 0 },
  rewardTier:             { type: String, enum: ['bronze', 'silver', 'gold', 'platinum'], default: 'bronze' },
  totalComplaintsFiled:   { type: Number, default: 0 },
  genuineComplaintsCount: { type: Number, default: 0 },
  rewardHistory:          [RewardHistorySchema],

  // Worker pay tracking
  basePay:          { type: Number, default: 15000 },
  currentPay:       { type: Number, default: 15000 },
  totalResolved:    { type: Number, default: 0 },
  performanceScore: { type: Number, default: 0 },
  monthlyResolved:  { type: Number, default: 0 },
  lastPayReview:    { type: Date, default: Date.now },
  payIncrements:    [PayIncrementSchema],
}, { timestamps: true });

// Hash password before save
UserSchema.pre('save', async function () {
  if (!this.isModified('password')) return;
  this.password = await bcrypt.hash(this.password, 10);
});

// Compare passwords
UserSchema.methods.comparePassword = function (candidatePassword) {
  return bcrypt.compare(candidatePassword, this.password);
};

// Get reward tier based on points
UserSchema.statics.getRewardTier = function (points) {
  if (points >= 600) return 'platinum';
  if (points >= 300) return 'gold';
  if (points >= 100) return 'silver';
  return 'bronze';
};

module.exports = mongoose.model('User', UserSchema);
