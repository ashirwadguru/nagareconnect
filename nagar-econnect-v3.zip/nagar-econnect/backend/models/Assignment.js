const mongoose = require('mongoose');

const AssignmentSchema = new mongoose.Schema({
  complaint:  { type: mongoose.Schema.Types.ObjectId, ref: 'Complaint', required: true },
  worker:     { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  supervisor: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  status: {
    type: String,
    enum: ['assigned','accepted','in_progress','completed'],
    default: 'assigned'
  },
  dueDate:    Date,
  notes:      String,
  completedAt: Date,
  workerNotes: String,

  // Status change audit
  statusHistory: [{
    status:    String,
    changedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    note:      String,
    timestamp: { type: Date, default: Date.now }
  }]
}, { timestamps: true });

module.exports = mongoose.model('Assignment', AssignmentSchema);
