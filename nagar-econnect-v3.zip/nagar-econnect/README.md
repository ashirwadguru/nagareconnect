# 🏙️ Nagar eConnect v3.0
## Smart Civic Complaint Management System — Odisha State

---

## 📁 Project Structure

```
nagar-econnect/
├── backend/
│   ├── server.js               ← Express entry point
│   ├── package.json
│   ├── .env.example            ← Copy to .env
│   ├── config/
│   │   ├── db.js               ← MongoDB connection
│   │   ├── odisha.js           ← Odisha districts/cities/wards data
│   │   └── seed.js             ← DB seeder
│   ├── models/
│   │   ├── User.js             ← User schema (citizen/worker/supervisor/admin)
│   │   ├── Complaint.js        ← Complaint schema with location & SLA
│   │   └── Assignment.js       ← Worker assignment schema
│   ├── middleware/
│   │   ├── auth.js             ← JWT auth + role middleware
│   │   └── engine.js           ← Business logic: rewards, pay, priority, SLA
│   └── routes/
│       ├── auth.js             ← Register, login, /me
│       ├── complaints.js       ← CRUD + status update (automated)
│       ├── assignments.js      ← Assign workers (automated sync)
│       ├── rewards.js          ← Citizen rewards + worker pay APIs
│       ├── admin.js            ← Admin dashboard + user management
│       └── odisha.js           ← Odisha state data APIs
│
└── frontend/
    ├── package.json
    ├── public/
    │   └── index.html
    └── src/
        ├── App.js              ← React Router setup
        ├── index.js            ← Entry point
        ├── context/
        │   └── AuthContext.js  ← Auth state (login/register/logout)
        ├── utils/
        │   └── api.js          ← Axios instance with JWT interceptor
        ├── components/
        │   ├── Navbar.js       ← Top navigation with role badge
        │   ├── PrivateRoute.js ← Route guard by role
        │   ├── ComplaintCard.js← Reusable complaint display + feedback
        │   └── ReportComplaint.js ← File complaint with GPS or typed location
        └── pages/
            ├── Login.js        ← Simple login → shows role after login
            ├── Register.js     ← Citizen registration with Odisha districts
            ├── CitizenDashboard.js  ← Report, track, rewards
            ├── WorkerDashboard.js   ← Tasks, automated status update → pay
            ├── SupervisorDashboard.js ← Assign workers, manage complaints
            └── AdminDashboard.js    ← Full analytics, all users, pay/rewards
```

---

## 🚀 Quick Start

### 1. Backend Setup
```bash
cd backend
npm install
cp .env.example .env
# Edit .env: set MONGO_URI if using Atlas
npm run dev
```

### 2. Frontend Setup (new terminal)
```bash
cd frontend
npm install
npm start
```

### 3. Seed Demo Data
```bash
# In browser console or curl:
curl -X POST http://localhost:5000/api/admin/seed
```

### 4. Open App
```
http://localhost:3000
```

---

## 🔑 Demo Credentials

| Role       | Email                            | Password      |
|------------|----------------------------------|---------------|
| Admin      | admin@nagareconnect.in           | Admin@123     |
| Supervisor | supervisor@nagareconnect.in      | Super@123     |
| Worker     | worker@nagareconnect.in          | Worker@123    |
| Citizen    | citizen@nagareconnect.in         | Citizen@123   |
| Citizen 2  | citizen2@nagareconnect.in        | Citizen@123   |
| Citizen 3  | citizen3@nagareconnect.in        | Citizen@123   |

---

## ⚙️ Automation — What Happens Automatically

### When a Citizen files a complaint:
- Priority auto-calculated (category + description keywords + photo)
- SLA deadline auto-set (critical=24h, high=48h, medium=96h, low=168h)
- Reward points auto-awarded (+10 base, +5 photo, +25 if critical)

### When a Worker updates assignment status (clicks button):
- Complaint status auto-synced (in_progress → complaint becomes in_progress)
- On "completed": complaint marked resolved, citizen gets +20 pts, worker pay checked
- Pay increment auto-triggered at milestones: 5/10/20/30/50/75/100 resolved

### When Admin/Supervisor marks complaint resolved:
- Citizen auto-awarded reward points
- Assignment auto-completed
- Worker pay auto-updated
- SLA bonus: +15 pts if resolved within deadline

### Background CRON (every hour):
- Scans all active complaints past SLA deadline → flags `slaBreached: true`

---

## 📍 Location Gate
- Recent complaints only shown when user's district is known (from profile or URL param)
- GPS detection built into Report Complaint form
- Falls back to manual district/city/ward selection (Odisha data pre-loaded)

---

## 🗺️ Odisha Districts Supported
Bhubaneswar · Cuttack · Rourkela · Puri · Sambalpur ·
Berhampur · Balasore · Angul · Koraput · Kendrapara

---

## 🏆 Reward Tiers (Citizens)

| Tier     | Points Required |
|----------|----------------|
| 🥉 Bronze   | 0+           |
| 🥈 Silver   | 100+         |
| 🥇 Gold     | 300+         |
| 💎 Platinum | 600+         |

## 💰 Worker Pay Milestones

| Complaints Resolved | Pay Increment |
|--------------------|---------------|
| 5                  | +₹500         |
| 10                 | +₹750         |
| 20                 | +₹1,000       |
| 30                 | +₹1,500       |
| 50                 | +₹2,000       |
| 75                 | +₹2,500       |
| 100                | +₹3,000       |

---

## 🔌 Key API Endpoints

```
POST   /api/auth/register              Public registration (citizens)
POST   /api/auth/login                 Login any role
GET    /api/auth/me                    Get current user

POST   /api/complaints                 File complaint (citizen)
GET    /api/complaints?district=X      List by district
GET    /api/complaints/my             My complaints
GET    /api/complaints/stats           Stats for area
PUT    /api/complaints/:id/status      Update status (auto-triggers rewards/pay)

POST   /api/assignments                Assign worker to complaint
GET    /api/assignments/my            Worker's assignments
PUT    /api/assignments/:id/status    Update (AUTO: syncs complaint + pay)

GET    /api/rewards/my                Citizen reward summary
GET    /api/rewards/worker/pay        Worker pay summary
GET    /api/rewards/leaderboard       Top citizens

GET    /api/admin/dashboard           Admin stats
POST   /api/admin/seed                Seed demo data
GET    /api/admin/users               All users

GET    /api/odisha/districts          Odisha districts
GET    /api/odisha/cities/:district   Cities in district
GET    /api/odisha/wards/:district    Wards in district
```
