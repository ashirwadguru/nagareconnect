import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../utils/api';
import Navbar from '../components/Navbar';

export default function AdminDashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [tab, setTab] = useState('overview');
  const [dashboard, setDashboard] = useState(null);
  const [workers, setWorkers] = useState([]);
  const [citizens, setCitizens] = useState([]);
  const [complaints, setComplaints] = useState([]);
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState('');
  const [updatingStatus, setUpdatingStatus] = useState('');

  useEffect(() => { if (!user) navigate('/login'); }, [user]);
  useEffect(() => {
    if (tab === 'overview') loadDashboard();
    if (tab === 'complaints') loadComplaints();
    if (tab === 'workers') loadWorkers();
    if (tab === 'rewards') loadCitizens();
  }, [tab]);

  const showToast = (msg) => { setToast(msg); setTimeout(() => setToast(''), 4000); };
  const loadDashboard = async () => { try { const r = await api.get('/admin/dashboard'); setDashboard(r.data); } catch { } };
  const loadComplaints = async () => {
    setLoading(true);
    try { const r = await api.get('/complaints?limit=50'); setComplaints(r.data.complaints || []); }
    catch { } finally { setLoading(false); }
  };
  const loadWorkers = async () => {
    setLoading(true);
    try { const r = await api.get('/rewards/admin/workers'); setWorkers(r.data.workers || []); }
    catch { } finally { setLoading(false); }
  };
  const loadCitizens = async () => {
    setLoading(true);
    try { const r = await api.get('/rewards/admin/overview'); setCitizens(r.data.citizens || []); }
    catch { } finally { setLoading(false); }
  };

  const updateComplaintStatus = async (complaintId, status) => {
    setUpdatingStatus(complaintId);
    try {
      const r = await api.put(`/complaints/${complaintId}/status`, { status });
      showToast(`✅ ${r.data.message}. Auto: ${r.data.autoActions?.join(' · ') || 'none'}`);
      await loadComplaints();
    } catch (err) {
      showToast(`❌ ${err.response?.data?.message || 'Failed'}`);
    } finally { setUpdatingStatus(''); }
  };

  if (!user) return null;
  const d = dashboard;

  return (
    <div style={styles.page}>
      <Navbar user={user} onLogout={() => { logout(); navigate('/login'); }} />
      {toast && <div style={styles.toast}>{toast}</div>}

      <div style={styles.header}>
        <h2 style={{ margin: 0 }}>🛡️ Admin Dashboard</h2>
        <p style={{ margin: '4px 0 0', color: '#64748b', fontSize: 14 }}>Nagar eConnect · Odisha State System</p>
      </div>

      <div style={styles.tabs}>
        {[['overview', '📊 Overview'], ['complaints', '📋 Complaints'], ['workers', '💰 Workers Pay'], ['rewards', '🏆 Citizens Rewards']].map(([t, label]) => (
          <button key={t} onClick={() => setTab(t)} style={{ ...styles.tab, ...(tab === t ? styles.activeTab : {}) }}>{label}</button>
        ))}
      </div>

      <div style={styles.content}>
        {tab === 'overview' && d && (
          <div>
            <div style={styles.statsGrid}>
              {[
                { label: 'Total Complaints', value: d.complaints.total, color: '#2563eb' },
                { label: 'Pending', value: d.complaints.pending, color: '#f59e0b' },
                { label: 'In Progress', value: d.complaints.inProgress, color: '#8b5cf6' },
                { label: 'Resolved', value: d.complaints.resolved, color: '#16a34a' },
                { label: 'Critical Active', value: d.complaints.critical, color: '#dc2626' },
                { label: 'SLA Breached', value: d.complaints.slaBreaches, color: '#ef4444' },
                { label: 'Resolution Rate', value: `${d.complaints.resolutionRate}%`, color: '#0891b2' },
                { label: 'Total Users', value: d.users.total, color: '#6366f1' },
              ].map(s => (
                <div key={s.label} style={styles.statCard}>
                  <div style={{ fontSize: 26, fontWeight: 700, color: s.color }}>{s.value}</div>
                  <div style={{ fontSize: 12, color: '#64748b' }}>{s.label}</div>
                </div>
              ))}
            </div>

            <h3 style={styles.sectionTitle}>District Breakdown</h3>
            {(d.districtBreakdown || []).map(db => (
              <div key={db._id} style={styles.districtRow}>
                <span style={{ fontWeight: 600 }}>{db._id || 'Unknown'}</span>
                <span>{db.count} complaints · {db.resolved} resolved</span>
              </div>
            ))}

            <h3 style={styles.sectionTitle}>Recent Complaints</h3>
            {(d.recentComplaints || []).map(c => (
              <div key={c._id} style={styles.card}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div>
                    <h4 style={{ margin: '0 0 4px', fontSize: 14 }}>{c.title}</h4>
                    <p style={{ margin: 0, color: '#64748b', fontSize: 12 }}>
                      {c.complaintId} · {c.location?.district || 'N/A'} · {new Date(c.createdAt).toLocaleDateString('en-IN')}
                    </p>
                  </div>
                  <span style={{ fontSize: 12, fontWeight: 700, color: '#fff', background: c.status === 'resolved' ? '#16a34a' : '#f59e0b', padding: '3px 10px', borderRadius: 12 }}>
                    {c.status?.replace('_', ' ').toUpperCase()}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === 'complaints' && (
          <div>
            <h3 style={styles.sectionTitle}>All Complaints</h3>
            {loading ? <p>Loading...</p> : complaints.map(c => (
              <div key={c._id} style={styles.card}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 8 }}>
                  <div style={{ flex: 1 }}>
                    <h4 style={{ margin: '0 0 4px', fontSize: 14 }}>{c.title}</h4>
                    <p style={{ margin: 0, color: '#64748b', fontSize: 12 }}>
                      {c.complaintId} · {c.location?.district || 'N/A'} · {c.location?.city || ''} · 👍 {c.upvotes}
                    </p>
                    <p style={{ margin: '4px 0 0', color: '#94a3b8', fontSize: 12 }}>
                      Filed: {new Date(c.createdAt).toLocaleDateString('en-IN')} · By: {c.citizen?.name || 'Unknown'}
                    </p>
                  </div>
                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                    {c.status !== 'resolved' && (
                      <button
                        onClick={() => updateComplaintStatus(c._id, 'resolved')}
                        disabled={updatingStatus === c._id}
                        style={{ ...styles.btn, background: '#16a34a' }}
                      >
                        {updatingStatus === c._id ? '...' : '✅ Resolve'}
                      </button>
                    )}
                    {c.status !== 'closed' && (
                      <button
                        onClick={() => updateComplaintStatus(c._id, 'closed')}
                        disabled={updatingStatus === c._id}
                        style={{ ...styles.btn, background: '#94a3b8' }}
                      >
                        Close
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === 'workers' && (
          <div>
            <h3 style={styles.sectionTitle}>Worker Pay Summary</h3>
            {loading ? <p>Loading...</p> : workers.map(w => (
              <div key={w._id} style={styles.card}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div>
                    <h4 style={{ margin: '0 0 4px', fontSize: 15 }}>{w.name}</h4>
                    <p style={{ margin: 0, color: '#64748b', fontSize: 13 }}>{w.email} · {w.district}, {w.city}</p>
                    <div style={{ marginTop: 8, display: 'flex', gap: 16, fontSize: 13, flexWrap: 'wrap' }}>
                      <span>📦 Resolved: <strong>{w.totalResolved}</strong></span>
                      <span>📅 This month: <strong>{w.monthlyResolved}</strong></span>
                      <span>🎯 Score: <strong>{w.performanceScore}/100</strong></span>
                    </div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontWeight: 700, color: '#16a34a', fontSize: 18 }}>₹{w.currentPay.toLocaleString('en-IN')}</div>
                    <div style={{ fontSize: 12, color: '#94a3b8' }}>Base: ₹{w.basePay.toLocaleString('en-IN')}</div>
                    {w.totalIncrements > 0 && <div style={{ fontSize: 12, color: '#16a34a' }}>+₹{w.totalIncrements.toLocaleString('en-IN')} earned</div>}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === 'rewards' && (
          <div>
            <h3 style={styles.sectionTitle}>Citizen Rewards Leaderboard</h3>
            {loading ? <p>Loading...</p> : citizens.map((c, i) => (
              <div key={c._id} style={styles.card}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                    <div style={{ fontSize: 22, fontWeight: 700, color: '#94a3b8', width: 32, textAlign: 'center' }}>#{i + 1}</div>
                    <div>
                      <h4 style={{ margin: '0 0 2px', fontSize: 15 }}>{c.name}</h4>
                      <p style={{ margin: 0, color: '#64748b', fontSize: 12 }}>{c.district} · {c.email}</p>
                    </div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontWeight: 700, fontSize: 18, color: { bronze: '#cd7f32', silver: '#94a3b8', gold: '#f59e0b', platinum: '#7c3aed' }[c.tier] }}>
                      {c.points} pts
                    </div>
                    <div style={{ fontSize: 12, textTransform: 'uppercase', color: '#64748b' }}>{c.tier}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

const styles = {
  page: { fontFamily: "'Segoe UI', sans-serif", minHeight: '100vh', background: '#f8fafc' },
  header: { padding: '20px 24px', background: '#fff', borderBottom: '3px solid #dc2626' },
  tabs: { display: 'flex', gap: 4, padding: '8px 16px', background: '#fff', borderBottom: '1px solid #f1f5f9', overflowX: 'auto' },
  tab: { padding: '8px 16px', fontSize: 13, border: 'none', borderRadius: 8, background: '#f1f5f9', cursor: 'pointer', color: '#64748b', whiteSpace: 'nowrap' },
  activeTab: { background: '#dc2626', color: '#fff' },
  content: { padding: '16px 16px 32px' },
  sectionTitle: { margin: '16px 0 12px', fontSize: 16, fontWeight: 700, color: '#1e293b' },
  statsGrid: { display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 24 },
  statCard: { background: '#fff', borderRadius: 12, padding: '14px 12px', textAlign: 'center', boxShadow: '0 1px 4px rgba(0,0,0,0.06)' },
  card: { background: '#fff', borderRadius: 12, padding: 16, marginBottom: 10, boxShadow: '0 1px 4px rgba(0,0,0,0.06)' },
  districtRow: { display: 'flex', justifyContent: 'space-between', background: '#fff', borderRadius: 10, padding: '10px 16px', marginBottom: 6, fontSize: 14, boxShadow: '0 1px 3px rgba(0,0,0,0.05)' },
  btn: { fontSize: 12, color: '#fff', border: 'none', borderRadius: 8, padding: '6px 14px', cursor: 'pointer', fontWeight: 600 },
  toast: { position: 'fixed', top: 70, right: 16, background: '#1e293b', color: '#fff', padding: '12px 20px', borderRadius: 10, zIndex: 999, fontSize: 13, maxWidth: 420 },
};
