import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const ROLE_INFO = {
  citizen:    { icon: '👤', label: 'Citizen',    color: '#2563eb', desc: 'Report issues & earn rewards' },
  worker:     { icon: '🔧', label: 'Worker',     color: '#16a34a', desc: 'Resolve complaints & earn pay increments' },
  supervisor: { icon: '📋', label: 'Supervisor', color: '#9333ea', desc: 'Assign workers & manage zones' },
  admin:      { icon: '🛡️', label: 'Admin',      color: '#dc2626', desc: 'Full system access & analytics' },
};

export default function Login() {
  const { login, loading } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loggedInUser, setLoggedInUser] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    const result = await login(email, password);
    if (result.success) {
      setLoggedInUser(result.user);
      setTimeout(() => {
        const role = result.user.role;
        if (role === 'citizen') navigate('/dashboard');
        else if (role === 'worker') navigate('/worker');
        else if (role === 'supervisor') navigate('/supervisor');
        else navigate('/admin');
      }, 1800);
    } else {
      setError(result.message);
    }
  };

  // Success screen — shows who you are after login
  if (loggedInUser) {
    const info = ROLE_INFO[loggedInUser.role] || ROLE_INFO.citizen;
    return (
      <div style={styles.page}>
        <div style={{ ...styles.card, textAlign: 'center' }}>
          <div style={{ fontSize: 64, marginBottom: 12 }}>{info.icon}</div>
          <div style={{ ...styles.roleBadge, background: info.color }}>
            {info.label}
          </div>
          <h2 style={{ margin: '16px 0 4px', color: '#1e293b' }}>Welcome, {loggedInUser.name}!</h2>
          <p style={{ color: '#64748b', marginBottom: 8 }}>{loggedInUser.email}</p>
          {loggedInUser.district && (
            <p style={{ color: '#64748b', fontSize: 14 }}>📍 {loggedInUser.district}, Odisha</p>
          )}
          <p style={{ color: info.color, marginTop: 16, fontSize: 15 }}>{info.desc}</p>
          <div style={styles.spinner}></div>
          <p style={{ color: '#94a3b8', fontSize: 13 }}>Redirecting to your dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <div style={styles.logo}>🏙️</div>
          <h1 style={styles.title}>Nagar eConnect</h1>
          <p style={styles.subtitle}>Odisha Smart Civic System</p>
        </div>

        {/* Login Form */}
        <form onSubmit={handleSubmit}>
          <div style={styles.field}>
            <label style={styles.label}>Email Address</label>
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="you@example.com"
              required
              style={styles.input}
            />
          </div>

          <div style={styles.field}>
            <label style={styles.label}>Password</label>
            <input
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="Enter your password"
              required
              style={styles.input}
            />
          </div>

          {error && (
            <div style={styles.error}>❌ {error}</div>
          )}

          <button type="submit" disabled={loading} style={styles.btn}>
            {loading ? 'Signing in...' : 'Sign In'}
          </button>
        </form>

        {/* Demo credentials */}
        <details style={styles.demoBox}>
          <summary style={styles.demoSummary}>Demo Credentials (click to expand)</summary>
          <div style={{ marginTop: 12 }}>
            {Object.entries(ROLE_INFO).map(([role, info]) => (
              <div
                key={role}
                style={styles.demoRow}
                onClick={() => {
                  setEmail(`${role}@nagareconnect.in`);
                  setPassword(role === 'citizen' ? 'Citizen@123' : role === 'worker' ? 'Worker@123' : role === 'supervisor' ? 'Super@123' : 'Admin@123');
                }}
              >
                <span>{info.icon} {info.label}</span>
                <span style={{ color: '#94a3b8', fontSize: 12 }}>{role}@nagareconnect.in</span>
              </div>
            ))}
          </div>
        </details>

        <p style={{ textAlign: 'center', marginTop: 20, color: '#64748b', fontSize: 14 }}>
          New citizen?{' '}
          <Link to="/register" style={{ color: '#2563eb', textDecoration: 'none', fontWeight: 600 }}>
            Create an account
          </Link>
        </p>
      </div>
    </div>
  );
}

const styles = {
  page: {
    minHeight: '100vh',
    background: 'linear-gradient(135deg, #1e3a5f 0%, #0f2238 100%)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    fontFamily: "'Segoe UI', sans-serif",
  },
  card: {
    background: '#fff',
    borderRadius: 16,
    padding: '40px 36px',
    width: '100%',
    maxWidth: 420,
    boxShadow: '0 20px 60px rgba(0,0,0,0.3)',
  },
  logo: { fontSize: 48, marginBottom: 8 },
  title: { margin: '0 0 4px', fontSize: 26, fontWeight: 700, color: '#1e293b' },
  subtitle: { margin: 0, color: '#64748b', fontSize: 14 },
  field: { marginBottom: 18 },
  label: { display: 'block', fontSize: 14, fontWeight: 600, color: '#374151', marginBottom: 6 },
  input: {
    width: '100%', padding: '10px 14px', fontSize: 15, border: '1.5px solid #e2e8f0',
    borderRadius: 8, outline: 'none', boxSizing: 'border-box',
    transition: 'border-color 0.2s',
  },
  error: {
    background: '#fef2f2', border: '1px solid #fecaca', color: '#dc2626',
    borderRadius: 8, padding: '10px 14px', fontSize: 14, marginBottom: 16
  },
  btn: {
    width: '100%', padding: '12px', fontSize: 16, fontWeight: 600,
    background: '#2563eb', color: '#fff', border: 'none', borderRadius: 8,
    cursor: 'pointer', marginTop: 4,
  },
  demoBox: {
    marginTop: 24, background: '#f8fafc', border: '1px solid #e2e8f0',
    borderRadius: 8, padding: '12px 16px', fontSize: 13
  },
  demoSummary: { cursor: 'pointer', fontWeight: 600, color: '#475569' },
  demoRow: {
    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
    padding: '8px 10px', marginTop: 6, background: '#fff', borderRadius: 6,
    border: '1px solid #e2e8f0', cursor: 'pointer', fontSize: 13,
  },
  roleBadge: {
    display: 'inline-block', color: '#fff', padding: '4px 18px', borderRadius: 20,
    fontSize: 15, fontWeight: 700, letterSpacing: 1
  },
  spinner: {
    width: 32, height: 32, border: '3px solid #e2e8f0',
    borderTop: '3px solid #2563eb', borderRadius: '50%',
    animation: 'spin 0.8s linear infinite', margin: '20px auto 8px',
  },
};
