import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../utils/api';
import Navbar from '../components/Navbar';
import ComplaintCard from '../components/ComplaintCard';
import ReportComplaint from '../components/ReportComplaint';

const TIER_COLORS = { bronze: '#cd7f32', silver: '#94a3b8', gold: '#f59e0b', platinum: '#7c3aed' };
const TIER_ICONS = { bronze: '🥉', silver: '🥈', gold: '🥇', platinum: '💎' };

export default function CitizenDashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [tab, setTab] = useState('home');
  const [complaints, setComplaints] = useState([]);
  const [rewards, setRewards] = useState(null);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState('');

  useEffect(() => { if (!user) navigate('/login'); }, [user]);

  useEffect(() => {
    if (tab === 'home' || tab === 'complaints') loadComplaints();
    if (tab === 'rewards') loadRewards();
  }, [tab]);

  useEffect(() => {
    if (user?.district) {
      api.get(`/complaints/stats?district=${user.district}`).then(r => setStats(r.data)).catch(() => {});
    }
  }, [user]);

  const loadComplaints = async () => {
    setLoading(true);
    try {
      const res = await api.get('/complaints/my');
      setComplaints(res.data.complaints || []);
    } catch { } finally { setLoading(false); }
  };

  const loadRewards = async () => {
    setLoading(true);
    try {
      const res = await api.get('/rewards/my');
      setRewards(res.data);
    } catch { } finally { setLoading(false); }
  };

  const showToast = (msg) => { setToast(msg); setTimeout(() => setToast(''), 3000); };

  if (!user) return null;
  const tier = user.rewardTier || 'bronze';

  return (
    <div style={styles.page}>
      <Navbar user={user} onLogout={() => { logout(); navigate('/login'); }} />

      {toast && <div style={styles.toast}>{toast}</div>}

      {/* Header */}
      <div style={{ ...styles.header, borderBottom: `3px solid ${TIER_COLORS[tier]}` }}>
        <div>
          <h2 style={{ margin: 0, fontSize: 22 }}>Hello, {user.name.split(' ')[0]} 👋</h2>
          <p style={{ margin: '4px 0 0', color: '#64748b', fontSize: 14 }}>
            📍 {user.district || 'Odisha'} · Citizen
          </p>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontSize: 28 }}>{TIER_ICONS[tier]}</div>
          <div style={{ color: TIER_COLORS[tier], fontWeight: 700, fontSize: 14, textTransform: 'uppercase' }}>{tier}</div>
          <div style={{ fontSize: 13, color: '#64748b' }}>{user.rewardPoints || 0} pts</div>
        </div>
      </div>

      {/* Area stats */}
      {stats && (
        <div style={styles.statsRow}>
          {[
            { label: 'Total', value: stats.total, color: '#2563eb' },
            { label: 'Pending', value: stats.pending, color: '#f59e0b' },
            { label: 'In Progress', value: stats.inProgress, color: '#8b5cf6' },
            { label: 'Resolved', value: stats.resolved, color: '#16a34a' },
          ].map(s => (
            <div key={s.label} style={styles.statCard}>
              <div style={{ fontSize: 24, fontWeight: 700, color: s.color }}>{s.value}</div>
              <div style={{ fontSize: 12, color: '#64748b' }}>{s.label}</div>
            </div>
          ))}
        </div>
      )}

      {/* Tabs */}
      <div style={styles.tabs}>
        {['home', 'complaints', 'report', 'rewards'].map(t => (
          <button key={t} onClick={() => setTab(t)} style={{ ...styles.tab, ...(tab === t ? styles.activeTab : {}) }}>
            {t === 'home' ? '🏠 Home' : t === 'complaints' ? '📋 My Complaints' : t === 'report' ? '➕ Report' : '🏆 Rewards'}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div style={styles.content}>
        {tab === 'home' && (
          <div>
            <h3 style={styles.sectionTitle}>Recent Complaints in {user.district || 'Your Area'}</h3>
            {loading ? <p>Loading...</p> : complaints.length === 0 ? (
              <div style={styles.empty}>
                <p>No complaints yet.</p>
                <button onClick={() => setTab('report')} style={styles.btnPrimary}>File Your First Complaint</button>
              </div>
            ) : complaints.slice(0, 5).map(c => (
              <ComplaintCard key={c._id} complaint={c} onUpdate={loadComplaints} showToast={showToast} />
            ))}
          </div>
        )}

        {tab === 'complaints' && (
          <div>
            <h3 style={styles.sectionTitle}>My Complaints</h3>
            {loading ? <p>Loading...</p> : complaints.length === 0 ? (
              <div style={styles.empty}><p>You haven't filed any complaints yet.</p></div>
            ) : complaints.map(c => (
              <ComplaintCard key={c._id} complaint={c} onUpdate={loadComplaints} showToast={showToast} showFeedback />
            ))}
          </div>
        )}

        {tab === 'report' && (
          <ReportComplaint user={user} onSuccess={() => { showToast('✅ Complaint filed!'); setTab('complaints'); loadComplaints(); }} />
        )}

        {tab === 'rewards' && rewards && (
          <RewardsTab rewards={rewards} />
        )}
      </div>
    </div>
  );
}

function RewardsTab({ rewards }) {
  const tier = rewards.tier || 'bronze';
  const tierColor = TIER_COLORS[tier];
  const progress = rewards.nextTier?.needed
    ? Math.max(0, 100 - Math.round((rewards.nextTier.needed / (rewards.nextTier.tier === 'silver' ? 100 : rewards.nextTier.tier === 'gold' ? 200 : 300)) * 100))
    : 100;

  return (
    <div>
      <div style={{ ...styles.rewardCard, borderColor: tierColor }}>
        <div style={{ fontSize: 48, marginBottom: 8 }}>{TIER_ICONS[tier]}</div>
        <h3 style={{ margin: 0, color: tierColor, textTransform: 'uppercase' }}>{tier} Tier</h3>
        <div style={{ fontSize: 36, fontWeight: 700, margin: '12px 0' }}>{rewards.points} pts</div>
        {rewards.nextTier?.needed > 0 && (
          <p style={{ color: '#64748b', fontSize: 14 }}>{rewards.nextTier.needed} more pts to reach {rewards.nextTier.tier}</p>
        )}
        <div style={styles.progressBar}>
          <div style={{ ...styles.progressFill, width: `${progress}%`, background: tierColor }} />
        </div>
      </div>

      <div style={styles.statsRow}>
        <div style={styles.statCard}><div style={{ fontSize: 22, fontWeight: 700 }}>{rewards.totalComplaints}</div><div style={{ fontSize: 12, color: '#64748b' }}>Filed</div></div>
        <div style={styles.statCard}><div style={{ fontSize: 22, fontWeight: 700, color: '#16a34a' }}>{rewards.resolvedComplaints}</div><div style={{ fontSize: 12, color: '#64748b' }}>Resolved</div></div>
        <div style={styles.statCard}><div style={{ fontSize: 22, fontWeight: 700, color: '#f59e0b' }}>{rewards.pendingComplaints}</div><div style={{ fontSize: 12, color: '#64748b' }}>Pending</div></div>
      </div>

      <h3 style={styles.sectionTitle}>Reward History</h3>
      {(rewards.history || []).map((h, i) => (
        <div key={i} style={styles.historyRow}>
          <div>
            <div style={{ fontWeight: 600, fontSize: 14 }}>{h.reason}</div>
            <div style={{ fontSize: 12, color: '#94a3b8' }}>{new Date(h.date).toLocaleDateString('en-IN')}</div>
          </div>
          <div style={{ color: '#16a34a', fontWeight: 700 }}>+{h.points} pts</div>
        </div>
      ))}
    </div>
  );
}

const styles = {
  page: { fontFamily: "'Segoe UI', sans-serif", minHeight: '100vh', background: '#f8fafc' },
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '20px 24px', background: '#fff', marginBottom: 16 },
  statsRow: { display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, padding: '0 16px 16px' },
  statCard: { background: '#fff', borderRadius: 12, padding: '14px 12px', textAlign: 'center', boxShadow: '0 1px 4px rgba(0,0,0,0.06)' },
  tabs: { display: 'flex', gap: 4, padding: '0 16px 8px', overflowX: 'auto' },
  tab: { padding: '8px 16px', fontSize: 13, border: 'none', borderRadius: 8, background: '#f1f5f9', cursor: 'pointer', whiteSpace: 'nowrap', color: '#64748b' },
  activeTab: { background: '#2563eb', color: '#fff' },
  content: { padding: '0 16px 32px' },
  sectionTitle: { margin: '16px 0 12px', fontSize: 16, fontWeight: 700, color: '#1e293b' },
  empty: { textAlign: 'center', padding: 40, color: '#94a3b8' },
  btnPrimary: { background: '#2563eb', color: '#fff', border: 'none', borderRadius: 8, padding: '10px 20px', fontSize: 14, cursor: 'pointer', marginTop: 12 },
  toast: { position: 'fixed', top: 70, right: 16, background: '#1e293b', color: '#fff', padding: '12px 20px', borderRadius: 10, zIndex: 999, fontSize: 14 },
  rewardCard: { background: '#fff', border: '2px solid', borderRadius: 16, padding: 28, textAlign: 'center', marginBottom: 16 },
  progressBar: { height: 8, background: '#f1f5f9', borderRadius: 4, marginTop: 12, overflow: 'hidden' },
  progressFill: { height: '100%', borderRadius: 4, transition: 'width 0.5s' },
  historyRow: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: '#fff', borderRadius: 10, padding: '12px 16px', marginBottom: 8, boxShadow: '0 1px 3px rgba(0,0,0,0.05)' },
};
