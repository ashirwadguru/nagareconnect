import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../utils/api';
import Navbar from '../components/Navbar';

const STATUS_COLORS = { pending: '#f59e0b', assigned: '#3b82f6', in_progress: '#8b5cf6', resolved: '#16a34a', closed: '#94a3b8' };
const PRIORITY_COLORS = { critical: '#dc2626', high: '#f97316', medium: '#eab308', low: '#22c55e' };

export default function SupervisorDashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [tab, setTab] = useState('complaints');
  const [complaints, setComplaints] = useState([]);
  const [workers, setWorkers] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState('');
  const [assigning, setAssigning] = useState('');
  const [selectedWorker, setSelectedWorker] = useState({});
  const [updatingStatus, setUpdatingStatus] = useState('');

  useEffect(() => { if (!user) navigate('/login'); }, [user]);
  useEffect(() => {
    if (tab === 'complaints') { loadComplaints(); loadWorkers(); }
    if (tab === 'assignments') loadAssignments();
    if (tab === 'workers') loadWorkers();
  }, [tab]);

  const showToast = (msg) => { setToast(msg); setTimeout(() => setToast(''), 4000); };

  const loadComplaints = async () => {
    setLoading(true);
    try {
      const r = await api.get(`/complaints?limit=30${user.district ? `&district=${user.district}` : ''}`);
      setComplaints(r.data.complaints || []);
    } catch { } finally { setLoading(false); }
  };

  const loadWorkers = async () => {
    try { const r = await api.get('/assignments/workers/list'); setWorkers(r.data.workers || []); } catch { }
  };

  const loadAssignments = async () => {
    setLoading(true);
    try { const r = await api.get('/assignments'); setAssignments(r.data.assignments || []); }
    catch { } finally { setLoading(false); }
  };

  const assignWorker = async (complaintId) => {
    const workerId = selectedWorker[complaintId];
    if (!workerId) { showToast('❌ Please select a worker'); return; }
    setAssigning(complaintId);
    try {
      await api.post('/assignments', { complaintId, workerId });
      showToast('✅ Worker assigned successfully!');
      await loadComplaints();
    } catch (err) {
      showToast(`❌ ${err.response?.data?.message || 'Assignment failed'}`);
    } finally { setAssigning(''); }
  };

  const updateComplaintStatus = async (complaintId, status) => {
    setUpdatingStatus(complaintId);
    try {
      const r = await api.put(`/complaints/${complaintId}/status`, { status });
      showToast(`✅ Status updated. ${r.data.autoActions?.join(' · ') || ''}`);
      await loadComplaints();
    } catch (err) {
      showToast(`❌ ${err.response?.data?.message || 'Update failed'}`);
    } finally { setUpdatingStatus(''); }
  };

  if (!user) return null;

  return (
    <div style={styles.page}>
      <Navbar user={user} onLogout={() => { logout(); navigate('/login'); }} />
      {toast && <div style={styles.toast}>{toast}</div>}

      <div style={styles.header}>
        <div>
          <h2 style={{ margin: 0 }}>📋 Supervisor Panel</h2>
          <p style={{ margin: '4px 0 0', color: '#64748b', fontSize: 14 }}>{user.name} · {user.district || 'Odisha'}</p>
        </div>
      </div>

      <div style={styles.tabs}>
        {[['complaints', '🗂️ Complaints'], ['assignments', '📌 Assignments'], ['workers', '👷 Workers']].map(([t, label]) => (
          <button key={t} onClick={() => setTab(t)} style={{ ...styles.tab, ...(tab === t ? styles.activeTab : {}) }}>{label}</button>
        ))}
      </div>

      <div style={styles.content}>
        {tab === 'complaints' && (
          <div>
            <h3 style={styles.sectionTitle}>Complaints — {user.district || 'All Areas'}</h3>
            {loading ? <p>Loading...</p> : complaints.map(c => (
              <div key={c._id} style={styles.card}>
                <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
                  <span style={{ ...styles.badge, background: PRIORITY_COLORS[c.priority] }}>{c.priority?.toUpperCase()}</span>
                  <span style={{ ...styles.badge, background: STATUS_COLORS[c.status] }}>{c.status?.replace('_', ' ').toUpperCase()}</span>
                </div>
                <h4 style={{ margin: '0 0 4px', fontSize: 15 }}>{c.title}</h4>
                <p style={{ margin: 0, color: '#64748b', fontSize: 13 }}>
                  📍 {c.location?.address || c.location?.city || 'N/A'} · {c.complaintId}
                </p>
                <p style={{ margin: '4px 0 0', color: '#94a3b8', fontSize: 12 }}>
                  Filed: {new Date(c.createdAt).toLocaleDateString('en-IN')} · 👍 {c.upvotes}
                </p>

                {/* Assign Worker */}
                {!['resolved', 'closed'].includes(c.status) && (
                  <div style={styles.assignRow}>
                    <select
                      value={selectedWorker[c._id] || ''}
                      onChange={e => setSelectedWorker(prev => ({ ...prev, [c._id]: e.target.value }))}
                      style={styles.select}
                    >
                      <option value="">Assign to worker...</option>
                      {workers.map(w => (
                        <option key={w._id} value={w._id}>
                          {w.name} ({w.activeAssignments} active, {w.completedAssignments} done)
                        </option>
                      ))}
                    </select>
                    <button
                      onClick={() => assignWorker(c._id)}
                      disabled={assigning === c._id}
                      style={styles.assignBtn}
                    >
                      {assigning === c._id ? '...' : 'Assign'}
                    </button>
                    <button
                      onClick={() => updateComplaintStatus(c._id, 'resolved')}
                      disabled={updatingStatus === c._id}
                      style={{ ...styles.assignBtn, background: '#16a34a' }}
                    >
                      ✅ Resolve
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {tab === 'assignments' && (
          <div>
            <h3 style={styles.sectionTitle}>All Assignments</h3>
            {loading ? <p>Loading...</p> : assignments.map(a => (
              <div key={a._id} style={styles.card}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div>
                    <h4 style={{ margin: '0 0 4px', fontSize: 14 }}>{a.complaint?.title}</h4>
                    <p style={{ margin: 0, color: '#64748b', fontSize: 13 }}>👷 {a.worker?.name} · {a.worker?.phone || 'No phone'}</p>
                    <p style={{ margin: '4px 0 0', color: '#94a3b8', fontSize: 12 }}>
                      ID: {a.complaint?.complaintId} · Due: {a.dueDate ? new Date(a.dueDate).toLocaleDateString('en-IN') : 'N/A'}
                    </p>
                  </div>
                  <span style={{ ...styles.badge, background: STATUS_COLORS[a.status] }}>
                    {a.status?.replace('_', ' ').toUpperCase()}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === 'workers' && (
          <div>
            <h3 style={styles.sectionTitle}>Worker Overview</h3>
            {workers.map(w => (
              <div key={w._id} style={styles.card}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <div>
                    <h4 style={{ margin: '0 0 4px', fontSize: 15 }}>{w.name}</h4>
                    <p style={{ margin: 0, color: '#64748b', fontSize: 13 }}>{w.email} · {w.phone || 'No phone'}</p>
                    <p style={{ margin: '4px 0 0', color: '#94a3b8', fontSize: 12 }}>
                      📍 {w.district || 'N/A'} · {w.city || ''}
                    </p>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontWeight: 700, color: '#16a34a' }}>₹{(w.currentPay || 15000).toLocaleString('en-IN')}</div>
                    <div style={{ fontSize: 12, color: '#64748b' }}>Score: {w.performanceScore || 0}/100</div>
                  </div>
                </div>
                <div style={{ marginTop: 12, display: 'flex', gap: 16, fontSize: 13 }}>
                  <span style={{ color: '#f59e0b' }}>📌 {w.activeAssignments} Active</span>
                  <span style={{ color: '#16a34a' }}>✅ {w.completedAssignments} Done</span>
                  <span style={{ color: '#64748b' }}>🎯 {w.totalResolved || 0} Total</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

const styles = {
  page: { fontFamily: "'Segoe UI', sans-serif", minHeight: '100vh', background: '#f8fafc' },
  header: { padding: '20px 24px', background: '#fff', marginBottom: 0 },
  tabs: { display: 'flex', gap: 4, padding: '8px 16px', background: '#fff', borderBottom: '1px solid #f1f5f9' },
  tab: { padding: '8px 16px', fontSize: 13, border: 'none', borderRadius: 8, background: '#f1f5f9', cursor: 'pointer', color: '#64748b' },
  activeTab: { background: '#9333ea', color: '#fff' },
  content: { padding: '16px 16px 32px' },
  sectionTitle: { margin: '0 0 12px', fontSize: 16, fontWeight: 700, color: '#1e293b' },
  card: { background: '#fff', borderRadius: 12, padding: 16, marginBottom: 12, boxShadow: '0 1px 4px rgba(0,0,0,0.06)' },
  badge: { fontSize: 11, fontWeight: 700, color: '#fff', padding: '3px 10px', borderRadius: 12 },
  assignRow: { display: 'flex', gap: 8, marginTop: 12, flexWrap: 'wrap', alignItems: 'center' },
  select: { flex: 1, minWidth: 200, padding: '7px 10px', fontSize: 13, border: '1.5px solid #e2e8f0', borderRadius: 8, outline: 'none' },
  assignBtn: { padding: '7px 14px', fontSize: 13, background: '#2563eb', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer', fontWeight: 600 },
  toast: { position: 'fixed', top: 70, right: 16, background: '#1e293b', color: '#fff', padding: '12px 20px', borderRadius: 10, zIndex: 999, fontSize: 13, maxWidth: 380 },
};
