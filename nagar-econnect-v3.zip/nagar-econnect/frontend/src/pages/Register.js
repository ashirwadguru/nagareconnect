import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../utils/api';

export default function Register() {
  const { register, loading } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '', phone: '', district: '', city: '', ward: '' });
  const [error, setError] = useState('');
  const [districts, setDistricts] = useState([]);
  const [cities, setCities] = useState([]);
  const [wards, setWards] = useState([]);

  useEffect(() => {
    api.get('/odisha/districts').then(r => setDistricts(r.data.districts)).catch(() => {});
  }, []);

  const handleDistrictChange = async (district) => {
    setForm(f => ({ ...f, district, city: '', ward: '' }));
    setCities([]); setWards([]);
    if (!district) return;
    try {
      const r = await api.get(`/odisha/cities/${district}`);
      setCities(r.data.cities);
      const w = await api.get(`/odisha/wards/${district}`);
      setWards(w.data.wards);
    } catch {}
  };

  const handleChange = e => setForm(f => ({ ...f, [e.target.name]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    if (!form.district) { setError('Please select your district in Odisha'); return; }
    const result = await register(form);
    if (result.success) navigate('/dashboard');
    else setError(result.message);
  };

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        <div style={{ textAlign: 'center', marginBottom: 28 }}>
          <div style={{ fontSize: 44 }}>🏙️</div>
          <h1 style={styles.title}>Create Account</h1>
          <p style={styles.subtitle}>Join as a Citizen · Odisha</p>
        </div>

        <form onSubmit={handleSubmit}>
          <div style={styles.row}>
            <Field label="Full Name *" name="name" value={form.name} onChange={handleChange} placeholder="Your full name" required />
            <Field label="Phone" name="phone" value={form.phone} onChange={handleChange} placeholder="10-digit mobile" type="tel" />
          </div>
          <Field label="Email Address *" name="email" type="email" value={form.email} onChange={handleChange} placeholder="you@example.com" required />
          <Field label="Password *" name="password" type="password" value={form.password} onChange={handleChange} placeholder="Minimum 6 characters" required />

          <hr style={{ border: 'none', borderTop: '1.5px solid #f1f5f9', margin: '16px 0' }} />
          <p style={{ fontSize: 13, fontWeight: 600, color: '#64748b', marginBottom: 12 }}>📍 Your Location in Odisha</p>

          <div style={styles.row}>
            <div style={styles.field}>
              <label style={styles.label}>District *</label>
              <select name="district" value={form.district} onChange={e => handleDistrictChange(e.target.value)} style={styles.input} required>
                <option value="">Select District</option>
                {districts.map(d => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>
            <div style={styles.field}>
              <label style={styles.label}>City / Area</label>
              <select name="city" value={form.city} onChange={handleChange} style={styles.input} disabled={!cities.length}>
                <option value="">Select City</option>
                {cities.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
          </div>

          <div style={styles.field}>
            <label style={styles.label}>Ward</label>
            <select name="ward" value={form.ward} onChange={handleChange} style={styles.input} disabled={!wards.length}>
              <option value="">Select Ward (optional)</option>
              {wards.map(w => <option key={w} value={w}>{w}</option>)}
            </select>
          </div>

          {error && <div style={styles.error}>❌ {error}</div>}

          <button type="submit" disabled={loading} style={styles.btn}>
            {loading ? 'Creating account...' : 'Create Account'}
          </button>
        </form>

        <p style={{ textAlign: 'center', marginTop: 18, color: '#64748b', fontSize: 14 }}>
          Already have an account?{' '}
          <Link to="/login" style={{ color: '#2563eb', textDecoration: 'none', fontWeight: 600 }}>Sign In</Link>
        </p>
      </div>
    </div>
  );
}

function Field({ label, name, value, onChange, placeholder, type = 'text', required }) {
  return (
    <div style={styles.field}>
      <label style={styles.label}>{label}</label>
      <input type={type} name={name} value={value} onChange={onChange} placeholder={placeholder} required={required} style={styles.input} />
    </div>
  );
}

const styles = {
  page: { minHeight: '100vh', background: 'linear-gradient(135deg, #1e3a5f 0%, #0f2238 100%)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20, fontFamily: "'Segoe UI', sans-serif" },
  card: { background: '#fff', borderRadius: 16, padding: '36px 32px', width: '100%', maxWidth: 480, boxShadow: '0 20px 60px rgba(0,0,0,0.3)' },
  title: { margin: '8px 0 4px', fontSize: 24, fontWeight: 700, color: '#1e293b' },
  subtitle: { margin: 0, color: '#64748b', fontSize: 14 },
  row: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 },
  field: { marginBottom: 16 },
  label: { display: 'block', fontSize: 13, fontWeight: 600, color: '#374151', marginBottom: 5 },
  input: { width: '100%', padding: '10px 12px', fontSize: 14, border: '1.5px solid #e2e8f0', borderRadius: 8, outline: 'none', boxSizing: 'border-box', background: '#fff' },
  error: { background: '#fef2f2', border: '1px solid #fecaca', color: '#dc2626', borderRadius: 8, padding: '10px 14px', fontSize: 14, marginBottom: 12 },
  btn: { width: '100%', padding: '12px', fontSize: 15, fontWeight: 600, background: '#2563eb', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer', marginTop: 4 },
};
