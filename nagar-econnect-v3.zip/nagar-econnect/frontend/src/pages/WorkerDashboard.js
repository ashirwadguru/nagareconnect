import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../utils/api';
import Navbar from '../components/Navbar';

const STATUS_OPTIONS = ['accepted', 'in_progress', 'completed'];
const STATUS_COLORS = { assigned: '#f59e0b', accepted: '#3b82f6', in_progress: '#8b5cf6', completed: '#16a34a' };
const PRIORITY_COLORS = { critical: '#dc2626', high: '#f97316', medium: '#eab308', low: '#22c55e' };

export default function WorkerDashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [tab, setTab] = useState('tasks');
  const [assignments, setAssignments] = useState([]);
  const [payInfo, setPayInfo] = useState(null);
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState('');
  const [updating, setUpdating] = useState('');

  useEffect(() => { if (!user) navigate('/login'); }, [user]);
  useEffect(() => { if (tab === 'tasks') loadAssignments(); if (tab === 'pay') loadPay(); }, [tab]);

  const loadAssignments = async () => {
    setLoading(true);
    try { const r = await api.get('/assignments/my'); setAssignments(r.data.assignments || []); }
    catch { } finally { setLoading(false); }
  };

  const loadPay = async () => {
    setLoading(true);
    try { const r = await api.get('/rewards/worker/pay'); setPayInfo(r.data); }
    catch { } finally { setLoading(false); }
  };

  const showToast = (msg) => { setToast(msg); setTimeout(() => setToast(''), 4000); };

  // AUTOMATED: When worker clicks "Update Status" → auto-syncs complaint + pay + rewards
  const updateStatus = async (assignmentId, newStatus) => {
    setUpdating(assignmentId);
    try {
      const r = await api.put(`/assignments/${assignmentId}/status`, { status: newStatus, note: `Worker updated to ${newStatus}` });
      showToast(`✅ Updated to "${newStatus}". ${r.data.autoActions?.join(' · ') || ''}`);
      await loadAssignments();
      if (newStatus === 'completed') await loadPay();
    } catch (err) {
      showToast(`❌ ${err.response?.data?.message || 'Update failed'}`);
    } finally { setUpdating(''); }
  };

  if (!user) return null;

  return (
    <div style={styles.page}>
      <Navbar user={user} onLogout={() => { logout(); navigate('/login'); }} />
      {toast && <div style={styles.toast}>{toast}</div>}

      <div style={styles.header}>
        <div>
          <h2 style={{ margin: 0 }}>🔧 Worker Panel</h2>
          <p style={{ margin: '4px 0 0', color: '#64748b', fontSize: 14 }}>
            {user.name} · {user.district || 'Odisha'}
          </p>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontWeight: 700, fontSize: 18, color: '#16a34a' }}>₹{(user.currentPay || 15000).toLocaleString('en-IN')}/mo</div>
          <div style={{ fontSize: 12, color: '#64748b' }}>Current Pay</div>
        </div>
      </div>

      <div style={styles.tabs}>
        {[['tasks', '📋 My Tasks'], ['pay', '💰 Pay & Milestones']].map(([t, label]) => (
          <button key={t} onClick={() => setTab(t)} style={{ ...styles.tab, ...(tab === t ? styles.activeTab : {}) }}>{label}</button>
        ))}
      </div>

      <div style={styles.content}>
        {tab === 'tasks' && (
          <div>
            <h3 style={styles.sectionTitle}>Assigned Complaints ({assignments.length})</h3>
            {loading ? <p>Loading...</p> : assignments.length === 0 ? (
              <div style={styles.empty}><p>No assignments yet. Check back soon.</p></div>
            ) : assignments.map(a => (
              <div key={a._id} style={styles.taskCard}>
                <div style={styles.taskHeader}>
                  <span style={{ ...styles.priorityBadge, background: PRIORITY_COLORS[a.complaint?.priority] || '#94a3b8' }}>
                    {a.complaint?.priority?.toUpperCase()}
                  </span>
                  <span style={{ ...styles.statusBadge, background: STATUS_COLORS[a.status] || '#94a3b8' }}>
                    {a.status?.replace('_', ' ').toUpperCase()}
                  </span>
                </div>
                <h4 style={{ margin: '10px 0 4px', fontSize: 15 }}>{a.complaint?.title}</h4>
                <p style={{ margin: 0, color: '#64748b', fontSize: 13 }}>
                  📍 {a.complaint?.location?.address || a.complaint?.location?.city || 'Location not specified'}
                </p>
                <p style={{ margin: '4px 0 0', color: '#94a3b8', fontSize: 12 }}>
                  ID: {a.complaint?.complaintId} · Due: {a.dueDate ? new Date(a.dueDate).toLocaleDateString('en-IN') : 'N/A'}
                </p>

                {/* Status Update - AUTOMATED */}
                {a.status !== 'completed' && (
                  <div style={styles.updateRow}>
                    <span style={{ fontSize: 13, color: '#475569' }}>Update status:</span>
                    <div style={{ display: 'flex', gap: 8 }}>
                      {STATUS_OPTIONS.filter(s => {
                        const order = ['assigned', 'accepted', 'in_progress', 'completed'];
                        return order.indexOf(s) > order.indexOf(a.status);
                      }).map(s => (
                        <button
                          key={s}
                          onClick={() => updateStatus(a._id, s)}
                          disabled={updating === a._id}
                          style={{ ...styles.statusBtn, background: STATUS_COLORS[s] }}
                        >
                          {updating === a._id ? '...' : s.replace('_', ' ')}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {a.status === 'completed' && (
                  <div style={{ marginTop: 10, padding: '8px 12px', background: '#f0fdf4', borderRadius: 8, fontSize: 13, color: '#16a34a' }}>
                    ✅ Completed on {a.completedAt ? new Date(a.completedAt).toLocaleDateString('en-IN') : 'N/A'}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {tab === 'pay' && payInfo && (
          <div>
            <div style={styles.payCard}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16 }}>
                <div>
                  <div style={{ fontSize: 13, color: '#64748b' }}>Base Pay</div>
                  <div style={{ fontSize: 20, fontWeight: 700 }}>₹{payInfo.basePay.toLocaleString('en-IN')}</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontSize: 13, color: '#64748b' }}>Current Pay</div>
                  <div style={{ fontSize: 24, fontWeight: 700, color: '#16a34a' }}>₹{payInfo.currentPay.toLocaleString('en-IN')}</div>
                </div>
              </div>
              <div style={{ background: '#f0fdf4', borderRadius: 8, padding: '10px 14px', fontSize: 14 }}>
                💰 Total Increments Earned: <strong style={{ color: '#16a34a' }}>+₹{payInfo.totalIncrements.toLocaleString('en-IN')}</strong>
              </div>

              <div style={styles.perf}>
                <div>🎯 Performance Score: <strong>{payInfo.performanceScore}/100</strong></div>
                <div>📦 Total Resolved: <strong>{payInfo.totalResolved}</strong></div>
                <div>📅 This Month: <strong>{payInfo.monthlyResolved}</strong></div>
              </div>

              {payInfo.nextMilestone && (
                <div style={styles.milestone}>
                  <div style={{ fontWeight: 600 }}>🎯 Next Milestone</div>
                  <div style={{ fontSize: 14, marginTop: 4 }}>
                    Resolve <strong>{payInfo.nextMilestone.remaining}</strong> more complaints to earn <strong style={{ color: '#16a34a' }}>+₹{payInfo.nextMilestone.increment.toLocaleString('en-IN')}</strong>
                  </div>
                  <div style={styles.progressBar}>
                    <div style={{ ...styles.progressFill, width: `${Math.round(((payInfo.nextMilestone.count - payInfo.nextMilestone.remaining) / payInfo.nextMilestone.count) * 100)}%` }} />
                  </div>
                </div>
              )}
            </div>

            <h3 style={styles.sectionTitle}>Pay Increment History</h3>
            {(payInfo.payHistory || []).length === 0 ? (
              <p style={{ color: '#94a3b8', fontSize: 14 }}>No increments yet. Keep resolving complaints!</p>
            ) : payInfo.payHistory.map((h, i) => (
              <div key={i} style={styles.historyRow}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>{h.reason}</div>
                  <div style={{ fontSize: 12, color: '#94a3b8' }}>{new Date(h.date).toLocaleDateString('en-IN')}</div>
                </div>
                <div style={{ color: '#16a34a', fontWeight: 700, fontSize: 16 }}>+₹{h.amount.toLocaleString('en-IN')}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

const styles = {
  page: { fontFamily: "'Segoe UI', sans-serif", minHeight: '100vh', background: '#f8fafc' },
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '20px 24px', background: '#fff', marginBottom: 8 },
  tabs: { display: 'flex', gap: 4, padding: '8px 16px', background: '#fff', borderBottom: '1px solid #f1f5f9' },
  tab: { padding: '8px 16px', fontSize: 13, border: 'none', borderRadius: 8, background: '#f1f5f9', cursor: 'pointer', color: '#64748b' },
  activeTab: { background: '#16a34a', color: '#fff' },
  content: { padding: '16px 16px 32px' },
  sectionTitle: { margin: '0 0 12px', fontSize: 16, fontWeight: 700, color: '#1e293b' },
  empty: { textAlign: 'center', padding: 40, color: '#94a3b8' },
  taskCard: { background: '#fff', borderRadius: 12, padding: '16px', marginBottom: 12, boxShadow: '0 1px 4px rgba(0,0,0,0.06)' },
  taskHeader: { display: 'flex', gap: 8 },
  priorityBadge: { fontSize: 11, fontWeight: 700, color: '#fff', padding: '3px 10px', borderRadius: 12 },
  statusBadge: { fontSize: 11, fontWeight: 700, color: '#fff', padding: '3px 10px', borderRadius: 12 },
  updateRow: { display: 'flex', alignItems: 'center', gap: 12, marginTop: 12, flexWrap: 'wrap' },
  statusBtn: { fontSize: 12, color: '#fff', border: 'none', borderRadius: 8, padding: '6px 14px', cursor: 'pointer', fontWeight: 600, textTransform: 'capitalize' },
  payCard: { background: '#fff', borderRadius: 16, padding: 24, marginBottom: 16, boxShadow: '0 2px 8px rgba(0,0,0,0.06)' },
  perf: { marginTop: 16, display: 'flex', gap: 16, flexWrap: 'wrap', fontSize: 14, color: '#475569' },
  milestone: { marginTop: 16, background: '#eff6ff', borderRadius: 10, padding: '14px 16px' },
  progressBar: { height: 8, background: '#dbeafe', borderRadius: 4, marginTop: 10, overflow: 'hidden' },
  progressFill: { height: '100%', background: '#2563eb', borderRadius: 4, transition: 'width 0.5s' },
  historyRow: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: '#fff', borderRadius: 10, padding: '12px 16px', marginBottom: 8, boxShadow: '0 1px 3px rgba(0,0,0,0.05)' },
  toast: { position: 'fixed', top: 70, right: 16, background: '#1e293b', color: '#fff', padding: '12px 20px', borderRadius: 10, zIndex: 999, fontSize: 13, maxWidth: 360 },
};
