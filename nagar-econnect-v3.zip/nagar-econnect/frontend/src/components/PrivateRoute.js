import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function PrivateRoute({ children, allowedRoles }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (allowedRoles && !allowedRoles.includes(user.role)) {
    // Redirect to correct dashboard based on role
    const roleRoutes = { citizen: '/dashboard', worker: '/worker', supervisor: '/supervisor', admin: '/admin' };
    return <Navigate to={roleRoutes[user.role] || '/login'} replace />;
  }
  return children;
}
