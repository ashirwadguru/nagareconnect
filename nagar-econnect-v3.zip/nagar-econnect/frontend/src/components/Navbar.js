import { useNavigate } from 'react-router-dom';

const ROLE_COLORS = { citizen: '#2563eb', worker: '#16a34a', supervisor: '#9333ea', admin: '#dc2626' };
const ROLE_ICONS = { citizen: '👤', worker: '🔧', supervisor: '📋', admin: '🛡️' };

export default function Navbar({ user, onLogout }) {
  const navigate = useNavigate();

  return (
    <nav style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '12px 20px', background: '#1e293b', color: '#fff',
      fontFamily: "'Segoe UI', sans-serif", position: 'sticky', top: 0, zIndex: 100,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer' }} onClick={() => navigate('/')}>
        <span style={{ fontSize: 22 }}>🏙️</span>
        <div>
          <div style={{ fontWeight: 700, fontSize: 15, lineHeight: 1 }}>Nagar eConnect</div>
          <div style={{ fontSize: 11, color: '#94a3b8' }}>Odisha Civic System</div>
        </div>
      </div>

      {user && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{
              width: 32, height: 32, borderRadius: '50%', display: 'flex', alignItems: 'center',
              justifyContent: 'center', fontSize: 14, fontWeight: 700, color: '#fff',
              background: ROLE_COLORS[user.role] || '#64748b',
            }}>
              {user.name?.charAt(0).toUpperCase()}
            </div>
            <div style={{ display: 'none' }}>
              <div style={{ fontSize: 13, fontWeight: 600 }}>{user.name?.split(' ')[0]}</div>
              <div style={{ fontSize: 11, color: '#94a3b8' }}>{ROLE_ICONS[user.role]} {user.role}</div>
            </div>
            <div style={{
              fontSize: 11, background: ROLE_COLORS[user.role] || '#64748b',
              color: '#fff', padding: '2px 10px', borderRadius: 12, fontWeight: 700,
              textTransform: 'uppercase', letterSpacing: 0.5
            }}>
              {ROLE_ICONS[user.role]} {user.role}
            </div>
          </div>
          <button
            onClick={onLogout}
            style={{
              fontSize: 12, background: 'transparent', color: '#94a3b8',
              border: '1px solid #334155', borderRadius: 8, padding: '6px 12px',
              cursor: 'pointer',
            }}
          >
            Logout
          </button>
        </div>
      )}
    </nav>
  );
}
