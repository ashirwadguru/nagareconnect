import { useState } from 'react';
import api from '../utils/api';

const STATUS_COLORS = { pending: '#f59e0b', assigned: '#3b82f6', in_progress: '#8b5cf6', resolved: '#16a34a', closed: '#94a3b8' };
const PRIORITY_COLORS = { critical: '#dc2626', high: '#f97316', medium: '#eab308', low: '#22c55e' };
const CATEGORY_LABELS = {
  dead_animal: '🐾 Dead Animal', sewage_overflow: '🚽 Sewage', road_blockage: '🚧 Road Block',
  overflowing_bin: '🗑️ Bin Full', stray_animals: '🐕 Stray Animals', garbage_dumping: '♻️ Garbage',
  construction_debris: '🏗️ Debris', waterlogging: '💧 Waterlogging', streetlight_issue: '💡 Streetlight',
  pothole: '🕳️ Pothole', illegal_encroachment: '⚠️ Encroachment', other: '📋 Other'
};

export default function ComplaintCard({ complaint: c, onUpdate, showToast, showFeedback = false }) {
  const [expanded, setExpanded] = useState(false);
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const submitFeedback = async () => {
    if (!rating) { showToast?.('❌ Please select a rating'); return; }
    setSubmitting(true);
    try {
      await api.post(`/complaints/${c._id}/feedback`, { rating, comment });
      showToast?.('✅ Feedback submitted! +5 pts');
      onUpdate?.();
    } catch (err) {
      showToast?.(`❌ ${err.response?.data?.message || 'Failed'}`);
    } finally { setSubmitting(false); }
  };

  const upvote = async () => {
    try {
      await api.post(`/complaints/${c._id}/upvote`);
      onUpdate?.();
    } catch { }
  };

  return (
    <div style={styles.card}>
      {/* Header */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 8, flexWrap: 'wrap' }}>
        <span style={{ ...styles.badge, background: PRIORITY_COLORS[c.priority] }}>{c.priority?.toUpperCase()}</span>
        <span style={{ ...styles.badge, background: STATUS_COLORS[c.status] }}>{c.status?.replace('_', ' ').toUpperCase()}</span>
        <span style={{ ...styles.badge, background: '#e2e8f0', color: '#475569' }}>{CATEGORY_LABELS[c.category] || c.category}</span>
      </div>

      {/* Title + ID */}
      <h4 style={{ margin: '0 0 4px', fontSize: 15, cursor: 'pointer' }} onClick={() => setExpanded(!expanded)}>
        {c.title}
      </h4>
      <p style={{ margin: 0, color: '#94a3b8', fontSize: 12 }}>
        🆔 {c.complaintId} · 📍 {c.location?.address || c.location?.city || 'Location N/A'}
      </p>
      <p style={{ margin: '4px 0 0', color: '#94a3b8', fontSize: 12 }}>
        🕐 {new Date(c.createdAt).toLocaleDateString('en-IN')} ·
        <button onClick={upvote} style={styles.upvoteBtn}>👍 {c.upvotes}</button>
      </p>

      {/* Expanded Details */}
      {expanded && (
        <div style={{ marginTop: 12, borderTop: '1px solid #f1f5f9', paddingTop: 12 }}>
          {c.description && <p style={{ fontSize: 14, color: '#475569', margin: '0 0 8px' }}>{c.description}</p>}
          {c.location?.ward && <p style={{ fontSize: 13, color: '#64748b', margin: 0 }}>🏘️ {c.location.ward}, {c.location.city}, {c.location.district}</p>}
          {c.resolvedAt && <p style={{ fontSize: 13, color: '#16a34a', margin: '6px 0 0' }}>✅ Resolved on {new Date(c.resolvedAt).toLocaleDateString('en-IN')}</p>}
        </div>
      )}

      {/* Feedback (citizen, resolved, not yet rated) */}
      {showFeedback && c.status === 'resolved' && !c.feedback?.rating && (
        <div style={styles.feedbackBox}>
          <p style={{ margin: '0 0 8px', fontSize: 13, fontWeight: 600 }}>Rate the resolution:</p>
          <div style={{ display: 'flex', gap: 6, marginBottom: 8 }}>
            {[1, 2, 3, 4, 5].map(n => (
              <button key={n} onClick={() => setRating(n)} style={{ ...styles.starBtn, color: n <= rating ? '#f59e0b' : '#e2e8f0' }}>★</button>
            ))}
          </div>
          <input
            value={comment} onChange={e => setComment(e.target.value)}
            placeholder="Optional comment..." style={styles.commentInput}
          />
          <button onClick={submitFeedback} disabled={submitting} style={styles.feedbackBtn}>
            {submitting ? '...' : 'Submit Feedback'}
          </button>
        </div>
      )}
      {c.feedback?.rating && (
        <div style={{ marginTop: 8, fontSize: 13, color: '#64748b' }}>
          Your rating: {'★'.repeat(c.feedback.rating)}{'☆'.repeat(5 - c.feedback.rating)}
        </div>
      )}
    </div>
  );
}

const styles = {
  card: { background: '#fff', borderRadius: 12, padding: 16, marginBottom: 10, boxShadow: '0 1px 4px rgba(0,0,0,0.06)' },
  badge: { fontSize: 11, fontWeight: 700, color: '#fff', padding: '3px 10px', borderRadius: 12 },
  upvoteBtn: { background: 'none', border: 'none', cursor: 'pointer', fontSize: 12, color: '#64748b', marginLeft: 6, padding: 0 },
  feedbackBox: { marginTop: 12, borderTop: '1px solid #f1f5f9', paddingTop: 12 },
  starBtn: { background: 'none', border: 'none', fontSize: 24, cursor: 'pointer', padding: '0 2px' },
  commentInput: { width: '100%', padding: '8px 10px', fontSize: 13, border: '1px solid #e2e8f0', borderRadius: 8, marginBottom: 8, boxSizing: 'border-box' },
  feedbackBtn: { padding: '7px 16px', background: '#2563eb', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer', fontSize: 13, fontWeight: 600 },
};
