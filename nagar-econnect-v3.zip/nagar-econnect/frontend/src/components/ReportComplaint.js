import { useState, useEffect } from 'react';
import api from '../utils/api';

const CATEGORIES = [
  ['dead_animal', '🐾 Dead Animal'],
  ['sewage_overflow', '🚽 Sewage Overflow'],
  ['road_blockage', '🚧 Road Blockage'],
  ['overflowing_bin', '🗑️ Overflowing Bin'],
  ['stray_animals', '🐕 Stray Animals'],
  ['garbage_dumping', '♻️ Garbage Dumping'],
  ['construction_debris', '🏗️ Construction Debris'],
  ['waterlogging', '💧 Waterlogging'],
  ['streetlight_issue', '💡 Streetlight Issue'],
  ['pothole', '🕳️ Pothole'],
  ['illegal_encroachment', '⚠️ Illegal Encroachment'],
  ['other', '📋 Other'],
];

export default function ReportComplaint({ user, onSuccess }) {
  const [form, setForm] = useState({
    title: '', description: '', category: '',
    latitude: '', longitude: '', address: '',
    ward: user?.ward || '', city: user?.city || '', district: user?.district || '',
  });
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [locating, setLocating] = useState(false);
  const [locMethod, setLocMethod] = useState(''); // 'gps' | 'typed'
  const [districts, setDistricts] = useState([]);
  const [cities, setCities] = useState([]);
  const [wards, setWards] = useState([]);

  useEffect(() => {
    api.get('/odisha/districts').then(r => setDistricts(r.data.districts)).catch(() => {});
    if (user?.district) loadCitiesWards(user.district);
  }, []);

  const loadCitiesWards = async (district) => {
    try {
      const [cr, wr] = await Promise.all([api.get(`/odisha/cities/${district}`), api.get(`/odisha/wards/${district}`)]);
      setCities(cr.data.cities);
      setWards(wr.data.wards);
    } catch {}
  };

  const handleChange = e => setForm(f => ({ ...f, [e.target.name]: e.target.value }));

  const handleDistrictChange = async (district) => {
    setForm(f => ({ ...f, district, city: '', ward: '' }));
    await loadCitiesWards(district);
  };

  // GPS location detection
  const detectGPS = () => {
    if (!navigator.geolocation) { setError('GPS not supported by your browser'); return; }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      pos => {
        setForm(f => ({ ...f, latitude: pos.coords.latitude.toFixed(6), longitude: pos.coords.longitude.toFixed(6) }));
        setLocMethod('gps');
        setLocating(false);
      },
      err => {
        setError('GPS failed: ' + err.message + '. Please type your address instead.');
        setLocating(false);
      },
      { timeout: 10000 }
    );
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (!form.category) { setError('Please select a category'); return; }
    if (!form.latitude || !form.longitude) {
      setError('Location is required. Use GPS or enter coordinates/address to continue.');
      return;
    }

    const data = new FormData();
    Object.entries(form).forEach(([k, v]) => { if (v) data.append(k, v); });
    files.forEach(f => data.append('images', f));

    setLoading(true);
    try {
      await api.post('/complaints', data, { headers: { 'Content-Type': 'multipart/form-data' } });
      onSuccess?.();
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to submit complaint');
    } finally { setLoading(false); }
  };

  const hasLocation = form.latitude && form.longitude;

  return (
    <div style={styles.container}>
      <h3 style={styles.sectionTitle}>📢 File a Complaint</h3>

      <form onSubmit={handleSubmit}>
        {/* Title */}
        <div style={styles.field}>
          <label style={styles.label}>Title *</label>
          <input name="title" value={form.title} onChange={handleChange} placeholder="Brief description of the issue" required style={styles.input} />
        </div>

        {/* Category */}
        <div style={styles.field}>
          <label style={styles.label}>Category *</label>
          <div style={styles.categoryGrid}>
            {CATEGORIES.map(([val, label]) => (
              <button
                type="button" key={val}
                onClick={() => setForm(f => ({ ...f, category: val }))}
                style={{ ...styles.catBtn, ...(form.category === val ? styles.catBtnActive : {}) }}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* Description */}
        <div style={styles.field}>
          <label style={styles.label}>Description</label>
          <textarea name="description" value={form.description} onChange={handleChange} placeholder="Additional details..." rows={3} style={{ ...styles.input, resize: 'vertical' }} />
        </div>

        {/* LOCATION — GPS or Typed */}
        <div style={styles.locationBox}>
          <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 10 }}>📍 Location *</div>

          {/* GPS Button */}
          <button type="button" onClick={detectGPS} disabled={locating} style={styles.gpsBtn}>
            {locating ? '🔄 Detecting location...' : '📡 Use My Current GPS Location'}
          </button>

          {hasLocation && locMethod === 'gps' && (
            <div style={styles.gpsSuccess}>
              ✅ GPS location detected: {form.latitude}, {form.longitude}
            </div>
          )}

          <div style={{ textAlign: 'center', color: '#94a3b8', fontSize: 13, margin: '10px 0' }}>— or enter manually —</div>

          <div style={styles.row}>
            <div style={styles.field}>
              <label style={styles.label}>Latitude</label>
              <input name="latitude" value={form.latitude} onChange={handleChange} placeholder="e.g. 20.2961" style={styles.input} />
            </div>
            <div style={styles.field}>
              <label style={styles.label}>Longitude</label>
              <input name="longitude" value={form.longitude} onChange={handleChange} placeholder="e.g. 85.8245" style={styles.input} />
            </div>
          </div>

          <div style={styles.field}>
            <label style={styles.label}>Address / Landmark</label>
            <input name="address" value={form.address} onChange={handleChange} placeholder="e.g. Near Rajmahal Square, Bhubaneswar" style={styles.input} />
          </div>

          <div style={styles.row}>
            <div style={styles.field}>
              <label style={styles.label}>District</label>
              <select name="district" value={form.district} onChange={e => handleDistrictChange(e.target.value)} style={styles.input}>
                <option value="">Select District</option>
                {districts.map(d => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>
            <div style={styles.field}>
              <label style={styles.label}>City</label>
              <select name="city" value={form.city} onChange={handleChange} style={styles.input} disabled={!cities.length}>
                <option value="">Select City</option>
                {cities.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div style={styles.field}>
              <label style={styles.label}>Ward</label>
              <select name="ward" value={form.ward} onChange={handleChange} style={styles.input} disabled={!wards.length}>
                <option value="">Select Ward</option>
                {wards.map(w => <option key={w} value={w}>{w}</option>)}
              </select>
            </div>
          </div>
        </div>

        {/* Photos */}
        <div style={styles.field}>
          <label style={styles.label}>Photos (optional, max 3)</label>
          <input type="file" accept="image/*" multiple onChange={e => setFiles(Array.from(e.target.files).slice(0, 3))} style={{ fontSize: 13 }} />
          {files.length > 0 && <p style={{ fontSize: 12, color: '#64748b', margin: '4px 0 0' }}>{files.length} file(s) selected · +5 pts bonus</p>}
        </div>

        {error && <div style={styles.error}>❌ {error}</div>}

        <button type="submit" disabled={loading || !hasLocation} style={{ ...styles.submitBtn, opacity: (!hasLocation || loading) ? 0.6 : 1 }}>
          {loading ? 'Submitting...' : !hasLocation ? '📍 Set Location First' : '📤 Submit Complaint'}
        </button>
      </form>
    </div>
  );
}

const styles = {
  container: { fontFamily: "'Segoe UI', sans-serif" },
  sectionTitle: { margin: '0 0 16px', fontSize: 18, fontWeight: 700, color: '#1e293b' },
  field: { marginBottom: 14 },
  label: { display: 'block', fontSize: 13, fontWeight: 600, color: '#374151', marginBottom: 5 },
  input: { width: '100%', padding: '10px 12px', fontSize: 14, border: '1.5px solid #e2e8f0', borderRadius: 8, outline: 'none', boxSizing: 'border-box', background: '#fff' },
  row: { display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 },
  categoryGrid: { display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 },
  catBtn: { padding: '8px 6px', fontSize: 12, border: '1.5px solid #e2e8f0', borderRadius: 8, background: '#f8fafc', cursor: 'pointer', textAlign: 'center' },
  catBtnActive: { border: '1.5px solid #2563eb', background: '#eff6ff', fontWeight: 700, color: '#2563eb' },
  locationBox: { background: '#f8fafc', border: '1.5px solid #e2e8f0', borderRadius: 12, padding: 16, marginBottom: 16 },
  gpsBtn: { width: '100%', padding: '12px', background: '#1e3a5f', color: '#fff', border: 'none', borderRadius: 8, fontSize: 14, fontWeight: 600, cursor: 'pointer' },
  gpsSuccess: { background: '#f0fdf4', border: '1px solid #bbf7d0', color: '#15803d', borderRadius: 8, padding: '8px 12px', fontSize: 13, marginTop: 8 },
  error: { background: '#fef2f2', border: '1px solid #fecaca', color: '#dc2626', borderRadius: 8, padding: '10px 14px', fontSize: 14, marginBottom: 12 },
  submitBtn: { width: '100%', padding: '13px', fontSize: 15, fontWeight: 700, background: '#2563eb', color: '#fff', border: 'none', borderRadius: 10, cursor: 'pointer' },
};
